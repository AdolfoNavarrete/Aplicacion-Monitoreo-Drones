import { io } from "socket.io-client";

const socket = io("https://proyecto-drone.sa.ngrok.io", { path: "/socket.io", transports: ["websocket"], autoConnect: true, reconnection: true});
export default socket