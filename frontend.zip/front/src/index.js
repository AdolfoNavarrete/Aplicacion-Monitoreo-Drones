import 'leaflet/dist/leaflet.css';
import './index.css';
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import reportWebVitals from './reportWebVitals';

// 1) Importa ToastContainer y sus estilos
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <App />
    <ToastContainer
      position="top-right"
      autoClose={5000}
      hideProgressBar
      closeOnClick
      pauseOnHover={false}
      draggable={false}
      toastStyle={{
        background: 'rgba(72, 187, 120, 0.9)',
        color: 'white',
        fontWeight: 'bold',
      }}
    />
  </>
);

reportWebVitals();
