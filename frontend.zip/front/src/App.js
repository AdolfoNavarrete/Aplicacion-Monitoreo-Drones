import React, { useState, useEffect, useMemo } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route
} from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import socket from './socket';
import Dashboard from './pages/Dashboard';
import CrearEmpresa from './pages/CrearEmpresa';
import CrearOperador from './pages/CrearOperador';
import CrearDron from './pages/CrearDron';
import CrearPlanVuelo from './pages/CrearPlanVuelo';
import './App.css';
import 'leaflet/dist/leaflet.css';
import HistorialPlanVuelo from './pages/HistorialPlanVuelo';
import DetallePlanVuelo from './pages/DetallePlanVuelo';
import HistorialVuelo from './pages/HistorialVuelo';
import DetalleVuelo from './pages/DetalleVuelo';

function App() {
  const [drones, setDrones] = useState([]);
  const [companies, setCompanies] = useState([]);

  const [dronePaths, setDronePaths] = useState(() => {
    try {
      const saved = sessionStorage.getItem('dronePaths');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      sessionStorage.setItem('dronePaths', JSON.stringify(dronePaths));
    } catch {}
  }, [dronePaths]);

  useEffect(() => {
    fetch('http://localhost:5000/api/drone/get_all')
      .then(res => res.json())
      .then(data => {
        console.log('🛸 Drones recibidos del backend:', data);
        setDrones(data);
      })
      .catch(err => console.error('Error fetching drones:', err));
  }, []);
  
  useEffect(() => {
    fetch('http://localhost:5000/api/drone-company/get_all')
      .then(res => res.json())
      .then(data => {
        console.log('🏭 Compañías recibidas del backend:', data);
        setCompanies(data);
      })
      .catch(err => console.error('Error fetching companies:', err));
  }, []);

  useEffect(() => {
    socket.on('welcome', data => {
      console.log('Servidor dice:', data);
      socket.emit('connect_front', {room : 'frontend'});
    });

    socket.on('alerta', alertData => {
      toast.warn(`⚠️ ${alertData.message}`, {
        position: 'top-right',
        autoClose: 5000,
        style: {
          background: '#f04d4d',
          color: '#fff'
        }
      });
    });
    
    socket.on('droneConnected', mensaje => {
      console.log('🛸 Dron conectado:', mensaje.nro_serie);
      const serial = mensaje.nro_serie;
      setDronePaths(prev => ({
        ...prev,
        [serial]: prev[serial] || [] // solo inicializa si no existe
      }));
    });

    socket.on('telemetryUpdate', ({ nro_serie, telemetry }) => {
       console.log('🛸 Nro serie:', nro_serie);
       console.log('🛸 Telemetry recibido del backend:', telemetry);
       console.log('📡 Estado actual de dronePaths:', JSON.stringify(dronePaths, null, 2));
      setDronePaths(prev => {
        const prevList = prev[nro_serie] || [];
        return {
          ...prev,
          [nro_serie]: [
            ...prevList,
            {
              lat: telemetry.lat,
              lon: telemetry.lon,
              altitud_msl: telemetry.altitud_msl,
              altitud_agl: telemetry.altitud_agl,
              velocidad: telemetry.velocidad,
              bateria: telemetry.bateria
            }
          ]
        };
      });
    });

    socket.on('droneDisconnected', mensaje => {
      console.log('🛑 Dron desconectado:', mensaje.nro_serie);
      setDronePaths(prev => {
        const updated = { ...prev };
        delete updated[mensaje.nro_serie];
        try {
          sessionStorage.setItem('dronePaths', JSON.stringify(updated));
        } catch {}
        return updated;
      });
    });
    return () => {
    };
  }, []);

  return (
    <Router>
      <ToastContainer />
      <Routes>
        {/* Ruta principal, le pasamos la lista de drones */}
        <Route path="/" element={<Dashboard drones={drones} dronePaths={dronePaths}/>} />
        {/* Ruta para el formulario de Crear Empresa */}
        <Route path="/ingresar-empresa" element={<CrearEmpresa />} />
        {/* Ruta para el formulario de Crear Operador */}
        <Route path="/ingresar-operador" element={<CrearOperador companies={companies} />} />
        {/* Ruta para el formulario de Crear Dron */}
        <Route path="/ingresar-dron" element={<CrearDron companies={companies} />} />
        {/* Ruta para el formulario de Crear Plan de Vuelo */}
        <Route path="/ingresar-plan-vuelo" element={<CrearPlanVuelo companies={companies} />} />
        {/* Ruta para el historial de planes de vuelo */}
        <Route path="/historial-planes" element={<HistorialPlanVuelo companies={companies}/>} />
        {/* Ruta para ver un plan de vuelo */}
        <Route path="/historial-planes/:id" element={<DetallePlanVuelo companies={companies} drones={drones}/>} />
        {/* Ruta para el historial de vuelos */}
        <Route path="/historial-vuelos" element={<HistorialVuelo companies={companies}/>} />
        {/* Ruta para ver un vuelo */}
        <Route path="/historial-vuelos/:id" element={<DetalleVuelo />} />
      </Routes>
    </Router>
  );
}

export default App;
