import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {toast} from 'react-toastify';

export default function CrearDronPage( {companies}) {
    const [nombre, setNombre] = useState('');
    const [tipo, setTipo] = useState('');
    const [marca, setMarca] = useState('');
    const [modelo, setModelo] = useState('');
    const [nro_serie, setSerial] = useState('');
    const [fabricante, setFabricante] = useState('');
    const [peso_fabrica, setPesoFabrica] = useState('');
    const [id_drone_company, setIdDronCompany] = useState('');

    const navigate = useNavigate();
  
    const handleSubmit = async e => {
        e.preventDefault();
        console.log({ nombre, tipo, marca, modelo, nro_serie, fabricante, peso_fabrica, id_drone_company });

        const payload = { nombre, tipo, marca, modelo, nro_serie, fabricante, peso_fabrica, id_drone_company: Number(id_drone_company) };

        console.group('🚀 Payload dron');
        Object.entries(payload).forEach(([key, value]) => {
            console.log(`${key}:`, value, `→ typeof:`, typeof value);
        });
        console.groupEnd();

        try {
        const resp = await fetch('http://localhost:5000/api/drone/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
        });

        if (!resp.ok) {
        let errMsg = `Error ${resp.status}`;
        const contentType = resp.headers.get('Content-Type') || '';
        if (contentType.includes('application/json')) {
            const errJson = await resp.json();
            errMsg = errJson.message || errMsg;
        }
        throw new Error(errMsg);
        }

        const data = await resp.json();
        console.log('Drone creado:', data);

        toast.success(`Dron "${nombre}" creado exitosamente!`);
        navigate('/');

    } catch (err) {
        console.error('Error creando dron:', err);
        toast.error(`No se pudo crear el dron: ${err.message}`);
    }
};

return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
        <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Aplicación de Monitoreo de Drones</h1>
        </header>

        {/* Content */}
        <div style={{ flex: 1, padding: '2rem', backgroundColor: '#f9fafb' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem' }}>Crear nuevo dron</h2>
        <form onSubmit={handleSubmit} style={{ maxWidth: '400px' }}>
            <div style={{ marginBottom: '1rem' }}>
            <label htmlFor="nombre" style={{ display: 'block', marginBottom: '.5rem' }}>
                Nombre
            </label>
            <input
                id="nombre"
                type="text"
                value={nombre}
                onChange={e => setNombre(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="tipo" style={{ display: 'block', marginBottom: '.5rem' }}>
                Tipo
            </label>
            <input
                id="tipo"
                type="text"
                value={tipo}
                onChange={e => setTipo(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="marca" style={{ display: 'block', marginBottom: '.5rem' }}>
                Marca
            </label>
            <input
                id="marca"
                type="text"
                value={marca}
                onChange={e => setMarca(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="modelo" style={{ display: 'block', marginBottom: '.5rem' }}>
                Modelo
            </label>
            <input
                id="modelo"
                type="text"
                value={modelo}
                onChange={e => setModelo(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="nro_serie" style={{ display: 'block', marginBottom: '.5rem' }}>
                Número de serie
            </label>
            <input
                id="nro_serie"
                type="text"
                value={nro_serie}
                onChange={e => setSerial(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="fabricante" style={{ display: 'block', marginBottom: '.5rem' }}>
                Fabricante
            </label>
            <input
                id="fabricante"
                type="text"
                value={fabricante}
                onChange={e => setFabricante(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label
                htmlFor="peso_fabrica"
                style={{ display: 'block', marginBottom: '.5rem' }}
            >
                Peso de fábrica
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                id="peso_fabrica"
                type="number"
                value={peso_fabrica}
                onChange={e => setPesoFabrica(parseInt(e.target.value, 10) || 0)}
                required
                style={{
                    width: '50%',      
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
                <span>gramos</span> 
            </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="company" style={{ display: 'block', marginBottom: '.5rem' }}>
                Empresa
            </label>
            <select
                id="company"
                value={id_drone_company}
                onChange={e => setIdDronCompany(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            >
                <option value="" disabled>— Elige una empresa —</option>
                {companies.map(c => (
                <option key={c.id_drone_company} value={c.id_drone_company}>
                    {c.razon_social}
                </option>
                ))}
            </select>
            </div>

            <button
            onClick={handleSubmit}
            type="submit"
            style={{
                backgroundColor: '#2563eb',
                color: '#fff',
                padding: '.75rem 1.5rem',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '1rem'
            }}
            >
            Guardar
            </button>
        </form>
        </div>
    </div>
    );
}
