import React, { useState, useEffect, useRef, useMemo} from 'react';
import {
  MapContainer,
  TileLayer,
  Polyline,
  CircleMarker,
  LayersControl,
  GeoJSON
} from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useNavigate } from 'react-router-dom';



export default function DashboardPage({ drones, dronePaths }) {
  console.log("🛸 DronPaths recibidos:", dronePaths);
  const [restrictedZones, setRestrictedZones] = useState(null);

  const [geojsonFile, setGeojsonFile] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(null);

  // Lista de drones
  const dronesDumm = [
    { nro_serie: "1", nombre: "Alpha", status: "Volando" },
    { nro_serie: "2", nombre: "Bravo", status: "Aterrizado" },
    { nro_serie: "3", nombre: "Charlie", status: "Volando" },
  ];

  // Telemetrías por dron (dronePaths)
  const dronePathsDumm = {
    "1": [
      { lat: -33.4489, lon: -70.6693, altitud_msl: 50.2, altitud_agl:  5.1, velocidad: 3.4, bateria:  92 },
      { lat: -33.4495, lon: -70.6688, altitud_msl: 52.0, altitud_agl:  6.9, velocidad: 4.1, bateria:  90 },
      { lat: -33.4501, lon: -70.6682, altitud_msl: 53.5, altitud_agl:  8.4, velocidad: 3.9, bateria:  89 },
    ],
    "2": [
      // dron 2 no está volando, path vacío
    ],
    "3": [
      { lat: -33.4600, lon: -70.6800, altitud_msl: 75.0, altitud_agl: 30.0, velocidad: 5.2, bateria:  80 },
      { lat: -33.4595, lon: -70.6795, altitud_msl: 76.5, altitud_agl: 31.5, velocidad: 5.0, bateria:  78 },
    ]
  };

  const activeDroneEntries = useMemo(() => {
    return Object
      .entries(dronePaths)
      .filter(([serial, path]) => Array.isArray(path) && path.length > 0);
  }, [dronePaths]);

  const mapRef = useRef(null);
  const navigate = useNavigate();

  const [visibleMap, setVisibleMap] = useState({});
  useEffect(() => {
    const initVis = {};
    drones.forEach(d => { initVis[d.id] = true; });
    setVisibleMap(initVis);
  }, [drones]);

  const toggleVisibility = id => {
    setVisibleMap(v => ({ ...v, [id]: !v[id] }));
  };

  // 2) Carga inicial de zonas restringidas
  const fetchZones = async () => {
    try {
      const resp = await fetch('http://localhost:5000/api/restricted_zones/get_all');
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      setRestrictedZones(await resp.json());
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchZones();
    }, []);

  // 3) Refrescar zonas tras subida
  useEffect(() => {
    if (uploadSuccess) fetchZones();
  }, [uploadSuccess]);

  // 4) Manejo de subida de GeoJSON
  const handleUploadZone = () => {
    setUploadError(null);
    setUploadSuccess(null);
    if (!geojsonFile) {
      setUploadError('Por favor selecciona primero un archivo GeoJSON.');
      return;
    }
    const reader = new FileReader();

    reader.onload = async evt => {
      try {
        const geojson = JSON.parse(evt.target.result);
        if (
          geojson.type !== 'FeatureCollection' ||
          !Array.isArray(geojson.features)
        ) {
          throw new Error('GeoJSON inválido: debe ser un FeatureCollection');
        }
        const resp = await fetch('/api/restricted_zones/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(geojson)
        });
        if (!resp.ok) {
          const contentType = resp.headers.get('Content-Type') || '';
          let errorMessage = 'Error al subir las zonas';
          if (contentType.includes('application/json')) {
            const payload = await resp.json();
            errorMessage = payload.message || errorMessage;
          } else {
            const text = await resp.text();
            errorMessage = text.substring(0, 200) + '…';
          }
          throw new Error(errorMessage);
        }
        setUploadSuccess('Zonas subidas correctamente.');
      } catch (err) {
        console.error(err);
        setUploadError(err.message);
      }
    };

    reader.onerror = () => {
      setUploadError('Error al leer el archivo.');
    };

    reader.readAsText(geojsonFile);
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
          Aplicación de Monitoreo de Drones
        </h1>
      </header>

      {/* Botones agregar */}
      <div
        style={{
          backgroundColor: '#fff',
          padding: '0.5rem 1rem',
          borderBottom: '1px solid #ddd',
          display: 'flex',
          alignItems: 'center'
        }}
      >
        <span style={{ marginRight: '0.5rem', fontWeight: '500' }}>Agregar:</span>
        <button
          style={{ marginRight: '0.5rem', padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/ingresar-empresa')}
        >
          Empresa
        </button>
        <button
          style={{ marginRight: '0.5rem', padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/ingresar-dron')}
        >
          Dron
        </button>
        <button
          style={{ marginRight: '0.5rem', padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/ingresar-operador')}
        >
          Operador
        </button>
        <button
          style={{ padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/ingresar-plan-vuelo')}
        >
          Plan de vuelo
        </button>
        
         <span style={{ marginLeft: '2rem', marginRight: '0.5rem', fontWeight: '500' }}>Historial de:</span>
        <button
          style={{ marginRight: '0.5rem', padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/historial-planes')}
        >
          Planes de vuelo
        </button>
        <button
          style={{ marginRight: '0.5rem', padding: '0.5rem', cursor: 'pointer' }}
          onClick={() => navigate('/historial-vuelos')}
        >
          Vuelos
        </button>
      </div>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Panel izquierdo */}
        <div
          style={{
            width: '40%', 
            borderRight: '1px solid #ddd',
            padding: '1rem',
            height: '100%',
            overflowY: 'auto'
          }}
        >
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#f3f4f6' }}>
                <th style={{ padding: '8px' }}>Nombre</th>
                <th style={{ padding: '8px', textAlign: 'center' }}>Altitud</th>
                <th style={{ padding: '8px', textAlign: 'center' }}>Batería</th>
                <th style={{ padding: '8px', textAlign: 'center' }}>Velocidad</th>
                <th style={{ padding: '8px', textAlign: 'center' }}>Mostrar</th>
                <th style={{ padding: '8px', textAlign: 'center' }}></th>
              </tr>
            </thead>
            <tbody>
              {activeDroneEntries.map(([serial, path]) => {
                const drone = drones.find(d => String(d.nro_serie) === String(serial));
                const name  = drone ? drone.nombre : 'Desconocido';
                const last  = path[path.length - 1];

                return (
                  <tr key={serial} style={{ borderTop: '1px solid #ddd' }}>
                    <td style={{ padding: '8px' }}>{name}</td>
                    <td style={{ padding: '8px', textAlign: 'center' }}>
                      AGL: {last.altitud_agl != null ? last.altitud_agl.toFixed(1) : '-'}<br/>
                      MSL: {last.altitud_msl != null ? last.altitud_msl.toFixed(1) : '-'}
                    </td>
                    <td style={{ padding: '8px', textAlign: 'center' }}>
                      {last.bateria != null ? `${last.bateria}%` : '-'}
                    </td>
                    <td style={{ padding: '8px', textAlign: 'center' }}>
                      {last.velocidad != null ? `${last.velocidad.toFixed(1)} m/s` : '-'}
                    </td>
                    <td style={{ padding: '8px', textAlign: 'center' }}>
                      <input
                        type="checkbox"
                        checked={!!visibleMap[serial]}
                        onChange={() => toggleVisibility(serial)}
                      />
                    </td>
                    <td style={{ padding: '8px', textAlign: 'center' }}>
                      <button
                        onClick={() => {
                          if (mapRef.current && last.lat != null && last.lon != null) {
                            mapRef.current.flyTo([last.lat, last.lon], 16);
                          }
                        }}
                        style={{
                          padding: '0.5rem 1rem',
                          cursor: 'pointer',
                          backgroundColor: '#2563eb',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px'
                        }}
                      >
                        Ir
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mapa + GeoJSON */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <div style={{ flex: 1 }}>
            <MapContainer
              ref={mapRef}
              center={[-33.4489, -70.6693]}
              zoom={12}
              style={{ height: '100%', width: '100%' }}
            >
              <LayersControl position="topright">
                <LayersControl.BaseLayer checked name="OpenStreetMap">
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution="&copy; OpenStreetMap contributors"
                  />
                </LayersControl.BaseLayer>
                <LayersControl.BaseLayer name="Satelite">
                  <TileLayer
                    url="https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}"
                    subdomains={['mt0', 'mt1', 'mt2', 'mt3']}
                  />
                </LayersControl.BaseLayer>
              </LayersControl>

              {Object.entries(dronePaths).map(([id, coords]) => {
                if (!visibleMap[id] || coords.length === 0) return null;

                const latlngs = coords
                .filter(point => typeof point.lat === 'number' && typeof point.lon === 'number')
                .map(point => [point.lat, point.lon]);

                if (latlngs.length === 0) return null; // También protegemos si todos los puntos eran inválidos

                return (
                  <React.Fragment key={id}>
                    <Polyline positions={latlngs} weight={5} color="red" />
                    {latlngs.map(([lat, lon], i) => (
                      <CircleMarker
                        key={`${id}-${i}`}
                        center={[lat, lon]}
                        radius={4}
                        pathOptions={{ color: 'black', fillOpacity: 0 }}
                      />
                    ))}
                  </React.Fragment>
                );
              })}

              {/* Zonas restringidas */}
              {restrictedZones && (
                <GeoJSON
                  data={restrictedZones}
                  style={() => ({
                    color: '#dc2626',
                    fillColor: '#f87171',
                    fillOpacity: 0.2,
                    weight: 2
                  })}
                />
              )}
            </MapContainer>
          </div>

          {/* Upload GeoJSON */}
          <div
            style={{
              padding: '0.5rem',
              borderTop: '1px solid #ddd',
              backgroundColor: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'flex-end',
              gap: '0.5rem'
            }}
          >
            <span style={{ fontWeight: 'bold' }}>Subir GeoJSON:</span>
            <input
              type="file"
              accept=".geojson,application/geo+json"
              onChange={e => {
                setGeojsonFile(e.target.files[0]);
                setUploadError(null);
                setUploadSuccess(null);
              }}
              style={{ padding: '0.25rem' }}
            />
            <button
              onClick={handleUploadZone}
              style={{
                padding: '0.5rem 1rem',
                cursor: 'pointer',
                backgroundColor: '#2563eb',
                color: '#fff',
                border: 'none',
                borderRadius: '4px'
              }}
            >
              Subir
            </button>
          </div>
          {uploadError && (
            <div style={{ color: 'red', padding: '0 1rem' }}>{uploadError}</div>
          )}
          {uploadSuccess && (
            <div style={{ color: 'green', padding: '0 1rem' }}>{uploadSuccess}</div>
          )}
        </div>
      </div>
    </div>
  );
}
