import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {toast} from 'react-toastify';

export default function CrearPlanVuelo( {companies}) {
    const [trabajo, setTrabajo] = useState('');
    const [fecha_inicio, setFechaInicio] = useState('');
    const [fecha_fin, setFechaFin] = useState('');
    const [dist_aerodromo, setDistAerodromo] = useState('');
    const [tipo_vuelo, setTipoVuelo] = useState('');
    const [rut_operador, setRutOperador] = useState('');
    const [nro_serie_dron, setNroSerieDron] = useState('');
    const [agl_max, setAglMax] = useState('');
    const [msl_max, setMslMax] = useState('');
    const [tiempo_max, setTiempoMax] = useState('');
    const [vel_max, setVelMax] = useState('');
    const [vuelo_nocturno, setVueloNocturno] = useState(null);
    const [id_dron_company, setIdDronCompany] = useState('');
    const [kmzFile, setKmzFile] = useState(null);
    const [autFile, setAutFile] = useState(null);
    const [insFile, setInsFile] = useState(null);

    const [operators, setOperators] = useState([]);
    const [drones, setDrones] = useState([]);

    const navigate = useNavigate();

    useEffect(() => {
    if (!id_dron_company) {
      setOperators([]); 
      return;
    }
    fetch(`http://localhost:5000/api/drone-operator/get/${id_dron_company}`)
      .then(res => res.json())
      .then(data => setOperators(data))
      .catch(err => {
        console.error('Error fetching operators:', err);
        setOperators([]);
      });
    }, [id_dron_company]);

    useEffect(() => {
    if (!id_dron_company) {
      setDrones([]); 
      return;
    }
    fetch(`http://localhost:5000/api/drone/get/${id_dron_company}`)
      .then(res => res.json())
      .then(data => setDrones(data))
      .catch(err => {
        console.error('Error fetching drones:', err);
        setDrones([]);
      });
    }, [id_dron_company]);

    const handleSubmit = async e => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('trabajo', trabajo);
        formData.append('fecha_inicio', fecha_inicio);
        formData.append('fecha_fin', fecha_fin);
        formData.append('dist_aerodromo', dist_aerodromo);
        formData.append('tipo_vuelo', tipo_vuelo);
        formData.append('rut_operador', rut_operador);
        formData.append('nro_serie_dron', nro_serie_dron);
        formData.append('agl_max', agl_max);
        formData.append('msl_max', msl_max);
        formData.append('tiempo_max', tiempo_max);
        formData.append('vel_max', vel_max);
        formData.append('vuelo_nocturno', vuelo_nocturno);
        formData.append('id_dron_company', id_dron_company);

        formData.append('kmzFile', kmzFile);
        formData.append('autFile', autFile);
        formData.append('insFile', insFile);

        console.group('🔍 FormData entries');
        for (let [key, value] of formData.entries()) {
            console.log(
            `${key}:`, 
            value, 
            `→ typeof: ${typeof value}`, 
            value instanceof File ? `(File — name: ${value.name})` : ''
            );
        }
        console.groupEnd();

        try {
            const resp = await fetch('http://localhost:5000/api/flight-plan/create', {
            method: 'POST',
            body: formData
            });

            if (!resp.ok) {
            let errMsg = `Error ${resp.status}`;
            const contentType = resp.headers.get('Content-Type') || '';
            if (contentType.includes('application/json')) {
                const errJson = await resp.json();
                errMsg = errJson.message || errMsg;
            }
            throw new Error(errMsg);
            }

            const data = await resp.json();
            console.log('Plan de vuelo creado:', data);
            toast.success(`Plan de vuelo creado exitosamente!`);
            navigate('/');
        } catch (err) {
            console.error('Error creando plan de vuelo:', err);
            toast.error(`No se pudo crear el plan de vuelo: ${err.message}`);
        }
    };

return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Aplicación de Monitoreo de Drones</h1>
      </header>

      <div style={{ flex: 1, padding: '2rem', backgroundColor: '#f9fafb' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem' }}>Crear nuevo plan de vuelo</h2>
        <form onSubmit={handleSubmit} style={{ maxWidth: '800px' }}>
          {/* grid container */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '1.5rem',
              alignItems: 'start'
            }}
          >
            {/* Columna 1 */}
            <div>
              <label htmlFor="company" style={{ display: 'block', marginBottom: '.5rem' }}>
                Empresa
              </label>
              <select
                id="company"
                value={id_dron_company}
                onChange={e => {
                    const id = e.target.value;
                    setIdDronCompany(id);
                    // 👉 Limpiamos selecciones previas
                    setRutOperador('');
                    setNroSerieDron('');
                    setOperators([]);
                    setDrones([]);
                }}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              >
                <option value="" disabled>— Elige una empresa —</option>
                {companies.map(c => (
                  <option key={c.id_drone_company} value={c.id_drone_company}>
                    {c.razon_social}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="rut_operador" style={{ display: 'block', marginBottom: '.5rem' }}>
                Operador
              </label>
              <select
                id="rut_operador"
                value={rut_operador}
                onChange={e => setRutOperador(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              >
                <option value="" disabled>— Elige un operador —</option>
                {operators.map(op => (
                  <option key={op.rut} value={op.rut}>
                    {op.nombre}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="nro_serie_dron" style={{ display: 'block', marginBottom: '.5rem' }}>
                Dron
              </label>
              <select
                id="nro_serie_dron"
                value={nro_serie_dron}
                onChange={e => setNroSerieDron(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              >
                <option value="" disabled>— Elige un dron —</option>
                {drones.map(dr => (
                  <option key={dr.nro_serie} value={dr.nro_serie}>
                    {dr.nombre}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="trabajo" style={{ display: 'block', marginBottom: '.5rem' }}>
                Trabajo
              </label>
              <input
                id="trabajo"
                type="text"
                value={trabajo}
                onChange={e => setTrabajo(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="fecha_inicio" style={{ display: 'block', marginBottom: '.5rem' }}>
                Fecha de inicio
              </label>
              <input
                id="fecha_inicio"
                type="date"
                value={fecha_inicio}
                onChange={e => setFechaInicio(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="fecha_fin" style={{ display: 'block', marginBottom: '.5rem' }}>
                Fecha de fin
              </label>
              <input
                id="fecha_fin"
                type="date"
                value={fecha_fin}
                onChange={e => setFechaFin(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="dist_aerodromo" style={{ display: 'block', marginBottom: '.5rem' }}>
                Distancia al aeródromo más cercano
              </label>
              <input
                id="dist_aerodromo"
                type="text"
                value={dist_aerodromo}
                onChange={e => setDistAerodromo(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="tipo_vuelo" style={{ display: 'block', marginBottom: '.5rem' }}>
                Tipo de vuelo
              </label>
              <input
                id="tipo_vuelo"
                type="text"
                value={tipo_vuelo}
                onChange={e => setTipoVuelo(e.target.value)}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label
                htmlFor="agl_max"
                style={{ display: 'block', marginBottom: '.5rem' }}
            >
                Altitud AGL máxima
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                id="agl_max"
                type="number"
                value={agl_max}
                onChange={e => setAglMax(parseInt(e.target.value, 10) || 0)}
                required
                style={{
                    width: '50%',      
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
                <span>metros</span> 
            </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label
                htmlFor="msl_max"
                style={{ display: 'block', marginBottom: '.5rem' }}
            >
                Altitud MSL máxima
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                id="msl_max"
                type="number"
                value={msl_max}
                onChange={e => setMslMax(parseInt(e.target.value, 10) || 0)}
                required
                style={{
                    width: '50%',      
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
                <span>metros</span> 
            </div>
            </div>

            <div style={{ marginBottom: '1.5rem' }}>
            <label
                htmlFor="tiempo_max"
                style={{ display: 'block', marginBottom: '.5rem' }}
            >
                Tiempo de vuelo máximo
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                id="tiempo_max"
                type="number"
                value={tiempo_max}
                onChange={e => setTiempoMax(parseInt(e.target.value, 10) || 0)}
                required
                style={{
                    width: '50%',      
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
                <span>minutos</span> 
            </div>
            </div>
            
            <div style={{ marginBottom: '1.5rem' }}>
            <label
                htmlFor="vel_max"
                style={{ display: 'block', marginBottom: '.5rem' }}
            >
                Velocidad máxima
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <input
                id="vel_max"
                type="number"
                value={vel_max}
                onChange={e => setVelMax(parseInt(e.target.value, 10) || 0)}
                required
                style={{
                    width: '50%',      
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
                <span>Km/h</span> 
            </div>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '.5rem' }}>
                Vuelo nocturno
              </label>
              <div>
                <label style={{ marginRight: '1rem' }}>
                  <input
                    type="radio"
                    name="vuelo_nocturno"
                    checked={vuelo_nocturno === true}
                    onChange={() => setVueloNocturno(true)}
                  />{' '}
                  Sí
                </label>
                <label>
                  <input
                    type="radio"
                    name="vuelo_nocturno"
                    checked={vuelo_nocturno === false}
                    onChange={() => setVueloNocturno(false)}
                  />{' '}
                  No
                </label>
              </div>
            </div>

            <div>
              <label htmlFor="kmzFile" style={{ display: 'block', marginBottom: '.5rem' }}>
                Archivo KMZ
              </label>
              <input
                id="kmzFile"
                type="file"
                accept=".kmz"
                onChange={e => setKmzFile(e.target.files[0])}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="autFile" style={{ display: 'block', marginBottom: '.5rem' }}>
                Archivo de autorización
              </label>
              <input
                id="autFile"
                type="file"
                accept=".pdf"
                onChange={e => setAutFile(e.target.files[0])}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>

            <div>
              <label htmlFor="insFile" style={{ display: 'block', marginBottom: '.5rem' }}>
                Póliza de seguro
              </label>
              <input
                id="insFile"
                type="file"
                accept=".pdf"
                onChange={e => setInsFile(e.target.files[0])}
                required
                style={{
                  width: '100%',
                  padding: '.5rem',
                  border: '1px solid #ccc',
                  borderRadius: '4px'
                }}
              />
            </div>
          </div>

          <button
            type="submit"
            style={{
              marginTop: '2rem',
              gridColumn: 'span 2',
              backgroundColor: '#2563eb',
              color: '#fff',
              padding: '.75rem 1.5rem',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '1rem'
            }}
          >
            Guardar
          </button>
        </form>
      </div>
    </div>
  );
}