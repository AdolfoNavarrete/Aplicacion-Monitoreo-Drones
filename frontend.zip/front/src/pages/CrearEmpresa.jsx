import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {toast} from 'react-toastify';


export default function CrearEmpresaPage() {
  const [razon_social, setRazonSocial] = useState('');
  const [nro_certificado, setCertificado] = useState('');
  const [rut, setRut] = useState('');
  const [actividad, setActividad] = useState('');
  const [direccion, setDireccion] = useState('');
  const [nro_contacto, setNroContacto] = useState('');
  const [nombre_responsable, setNombreResponsable] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async e => {
          e.preventDefault();
          console.log({  razon_social, nro_certificado, rut, actividad, direccion, nro_contacto, nombre_responsable  });
  
          const payload = {  razon_social, nro_certificado, rut, actividad, direccion, nro_contacto, nombre_responsable };
  
          console.group('🚀 Payload dron');
          Object.entries(payload).forEach(([key, value]) => {
              console.log(`${key}:`, value, `→ typeof:`, typeof value);
          });
          console.groupEnd();
  
          try {
          const resp = await fetch('http://localhost:5000/api/drone-company/create', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
          });
  
          if (!resp.ok) {
          let errMsg = `Error ${resp.status}`;
          const contentType = resp.headers.get('Content-Type') || '';
          if (contentType.includes('application/json')) {
              const errJson = await resp.json();
              errMsg = errJson.message || errMsg;
          }
          throw new Error(errMsg);
          }
  
          const data = await resp.json();
          console.log('Empresa creada:', data);
  
          toast.success(`Empresa "${razon_social}" creada exitosamente!`);
          navigate('/');
  
      } catch (err) {
          console.error('Error creando dron:', err);
          toast.error(`No se pudo crear el dron: ${err.message}`);
      }
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Aplicación de Monitoreo de Drones</h1>
      </header>

      {/* Content */}
      <div style={{ flex: 1, padding: '2rem', backgroundColor: '#f9fafb' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem' }}>Crear nueva empresa</h2>
        <form onSubmit={handleSubmit} style={{ maxWidth: '400px' }}>
          <div style={{ marginBottom: '1rem' }}>
            <label htmlFor="razon" style={{ display: 'block', marginBottom: '.5rem' }}>
              Razón social
            </label>
            <input
              id="razon"
              type="text"
              value={razon_social}
              onChange={e => setRazonSocial(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="certificado" style={{ display: 'block', marginBottom: '.5rem' }}>
              Número de certificado
            </label>
            <input
              id="certificado"
              type="text"
              value={nro_certificado}
              onChange={e => setCertificado(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="rut" style={{ display: 'block', marginBottom: '.5rem' }}>
              RUT
            </label>
            <input
              id="rut"
              type="text"
              value={rut}
              onChange={e => setRut(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="actividad" style={{ display: 'block', marginBottom: '.5rem' }}>
              Actividad
            </label>
            <input
              id="actividad"
              type="text"
              value={actividad}
              onChange={e => setActividad(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="direccion" style={{ display: 'block', marginBottom: '.5rem' }}>
              Dirección
            </label>
            <input
              id="direccion"
              type="text"
              value={direccion}
              onChange={e => setDireccion(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="nroContacto" style={{ display: 'block', marginBottom: '.5rem' }}>
              Número de contacto
            </label>
            <input
              id="nroContacto"
              type="text"
              value={nro_contacto}
              onChange={e => setNroContacto(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>
          
          <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="nombreResponsable" style={{ display: 'block', marginBottom: '.5rem' }}>
              Nombre responsable
            </label>
            <input
              id="nombreResponsable"
              type="text"
              value={nombre_responsable}
              onChange={e => setNombreResponsable(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
              }}
            />
          </div>

          <button
            onClick={handleSubmit}
            type="submit"
            style={{
              backgroundColor: '#2563eb',
              color: '#fff',
              padding: '.75rem 1.5rem',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '1rem'
            }}
          >
            Guardar
          </button>
        </form>
      </div>
    </div>
  );
}
