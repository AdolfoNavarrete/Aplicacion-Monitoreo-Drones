import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

export default function HistorialPlanVuelo({ companies }) {
  const [planes, setPlanes] = useState([]);
  const [sortConfig, setSortConfig] = useState({ key: 'fecha_inicio', direction: 'desc' });
  const navigate = useNavigate();

  const companiesMap = useMemo(
    () => Object.fromEntries(companies.map(e => [e.id_drone_company, e.razon_social])),
    [companies]
  );

  useEffect(() => {
    fetch('http://localhost:5000/api/flight-plan/get_all')
      .then(resp => resp.ok ? resp.json() : Promise.reject(`HTTP ${resp.status}`))
      .then(data => setPlanes(data))
      .catch(err => console.error(err));
  }, []);

  const sortedPlanes = useMemo(() => {
    if (!sortConfig.key) return planes;
    return [...planes].sort((a, b) => {
      const aVal = new Date(a[sortConfig.key]);
      const bVal = new Date(b[sortConfig.key]);
      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [planes, sortConfig]);

  const requestSort = key => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
          Aplicación de Monitoreo de Drones
        </h1>
      </header>

      <div style={{ flex: 1, padding: '1rem', overflow: 'auto' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem', fontWeight: '500' }}>
          Historial de Planes de Vuelo
        </h2>

        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f3f4f6' }}>
              <th style={{ padding: '8px', textAlign: 'left' }}>ID</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Empresa</th>
              <th
                style={{ padding: '8px', textAlign: 'left', cursor: 'pointer', userSelect: 'none' }}
                onClick={() => requestSort('fecha_inicio')}
              >
                Fecha de inicio{sortConfig.key === 'fecha_inicio'
                  ? (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')
                  : ''}
              </th>
              <th
                style={{ padding: '8px', textAlign: 'left', cursor: 'pointer', userSelect: 'none' }}
                onClick={() => requestSort('fecha_fin')}
              >
                Fecha de fin{sortConfig.key === 'fecha_fin'
                  ? (sortConfig.direction === 'asc' ? ' ▲' : ' ▼')
                  : ''}
              </th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Tipo de vuelo</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Autorizado</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Detalles</th>  {/* Nueva columna */}
            </tr>
          </thead>
          <tbody>
            {sortedPlanes.map(plan => (
              <tr key={plan.id_flight_plan} style={{ borderTop: '1px solid #ddd' }}>
                <td style={{ padding: '8px' }}>{plan.id_flight_plan}</td>
                <td style={{ padding: '8px' }}>
                  {companiesMap[plan.id_drone_company] || '–'}
                </td>
                <td style={{ padding: '8px' }}>
                  {new Date(plan.fecha_inicio).toLocaleDateString()}
                </td>
                <td style={{ padding: '8px' }}>
                  {new Date(plan.fecha_fin).toLocaleDateString()}
                </td>
                <td style={{ padding: '8px' }}>{plan.tipo_vuelo}</td>
                <td style={{ padding: '8px' }}>{plan.autorizado ? 'Sí' : 'No'}</td>
                <td style={{ padding: '8px' }}>
                  <button
                    style={{
                      padding: '4px 8px',
                      cursor: 'pointer',
                      backgroundColor: '#2563eb',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '4px'
                    }}
                    onClick={() => navigate(`/historial-planes/${plan.id_flight_plan}`)}
                  >
                    Ver
                  </button>
                </td>  {/* Botón para ir a detalles */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
