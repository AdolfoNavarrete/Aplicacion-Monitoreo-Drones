import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {toast} from 'react-toastify';

export default function CrearOperadorPage( {companies} ) {
    const [rut, setRut] = useState('');
    const [nombre, setNombre] = useState('');
    const [fecha_nacimiento, setFechaNacimiento] = useState('');
    const [telefono, setTelefono] = useState('');
    const [nro_credencial, setNroCredencial] = useState('');
    const [fecha_emision, setFechaEmision] = useState('');
    const [id_drone_company, setIdDronCompany] = useState('');

    const navigate = useNavigate();
  
    const handleSubmit = async e => {
        e.preventDefault();
        console.log({ rut, nombre, fecha_nacimiento, telefono, nro_credencial, fecha_emision, id_drone_company });

        const payload = {rut, nombre, fecha_nacimiento, telefono, nro_credencial, fecha_emision, id_drone_company: Number(id_drone_company) };

        console.group('🚀 Payload dron');
        Object.entries(payload).forEach(([key, value]) => {
            console.log(`${key}:`, value, `→ typeof:`, typeof value);
        });
        console.groupEnd();

        try {
        const resp = await fetch('http://localhost:5000/api/drone-operator/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
        });

        if (!resp.ok) {
        let errMsg = `Error ${resp.status}`;
        const contentType = resp.headers.get('Content-Type') || '';
        if (contentType.includes('application/json')) {
            const errJson = await resp.json();
            errMsg = errJson.message || errMsg;
        }
        throw new Error(errMsg);
        }

        const data = await resp.json();
        console.log('Drone creado:', data);

        toast.success(`Dron "${nombre}" creado exitosamente!`);
        navigate('/');

    } catch (err) {
        console.error('Error creando dron:', err);
        toast.error(`No se pudo crear el dron: ${err.message}`);
    }
};


return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
        <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Aplicación de Monitoreo de Drones</h1>
        </header>

        {/* Content */}
        <div style={{ flex: 1, padding: '2rem', backgroundColor: '#f9fafb' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem' }}>Crear nuevo operador</h2>
        <form onSubmit={handleSubmit} style={{ maxWidth: '400px' }}>
            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="rut" style={{ display: 'block', marginBottom: '.5rem' }}>
                RUT
                </label>
                <input
                id="rut"
                type="text"
                value={rut}
                onChange={e => setRut(e.target.value)}
                required
                style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
            </div>

            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="nombre" style={{ display: 'block', marginBottom: '.5rem' }}>
                Nombre
                </label>
                <input
                id="nombre"
                type="text"
                value={nombre}
                onChange={e => setNombre(e.target.value)}
                required
                style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
            </div>

            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="fechaNacimiento" style={{ display: 'block', marginBottom: '.5rem' }}>
                    Fecha de nacimiento
                </label>
                <input
                    id="fechaNacimiento"
                    type="date"
                    value={fecha_nacimiento}
                    onChange={e => setFechaNacimiento(e.target.value)}
                    required
                    style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                    }}
                />
            </div>  

            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="telefono" style={{ display: 'block', marginBottom: '.5rem' }}>
                Teléfono
                </label>
                <input
                id="telefono"
                type="text"
                value={telefono}
                onChange={e => setTelefono(e.target.value)}
                required
                style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
            </div>

            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="nroCredencial" style={{ display: 'block', marginBottom: '.5rem' }}>
                Número de credencial
                </label>
                <input
                id="nroCredencial"
                type="text"
                value={nro_credencial}
                onChange={e => setNroCredencial(e.target.value)}
                required
                style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                }}
                />
            </div>

            <div style={{ marginBottom: '1rem' }}>
                <label htmlFor="fechaEmision" style={{ display: 'block', marginBottom: '.5rem' }}>
                    Fecha de emisión
                </label>
                <input
                    id="fechaEmision"
                    type="date"
                    value={fecha_emision}
                    onChange={e => setFechaEmision(e.target.value)}
                    required
                    style={{
                    width: '100%',
                    padding: '.5rem',
                    border: '1px solid #ccc',
                    borderRadius: '4px'
                    }}
                />
            </div>  

            <div style={{ marginBottom: '1.5rem' }}>
            <label htmlFor="company" style={{ display: 'block', marginBottom: '.5rem' }}>
                Empresa
            </label>
            <select
                id="company"
                value={id_drone_company}
                onChange={e => setIdDronCompany(e.target.value)}
                required
                style={{
                width: '100%',
                padding: '.5rem',
                border: '1px solid #ccc',
                borderRadius: '4px'
                }}
            >
                <option value="" disabled>— Elige una empresa —</option>
                {companies.map(c => (
                <option key={c.id_drone_company} value={c.id_drone_company}>
                    {c.razon_social}
                </option>
                ))}
            </select>
            </div>

            <button
            onClick={handleSubmit}
                type="submit"
                style={{
                backgroundColor: '#2563eb',
                color: '#fff',
                padding: '.75rem 1.5rem',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '1rem'
                }}
            >
                Guardar
            </button>
        </form>
        </div>
    </div>
    );
}