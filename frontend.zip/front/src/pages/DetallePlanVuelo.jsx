import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, GeoJSON } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function DetallePlanVuelo({ companies, drones }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/api/flight-plan/get/${id}`)
      .then(res => res.ok ? res.json() : Promise.reject(res.status))
      .then(data => {
        console.log('Datos del plan cargados:', data);
        setPlan(data);
      })
      .catch(() => navigate('/historial-planes'));
  }, [id, navigate]);
  
  if (!plan) return <p>Cargando detalles…</p>;

  const empresa = companies.find(c => c.id_drone_company === plan.id_drone_company);
  const empresaNombre = empresa ? empresa.razon_social : '–';
  const nombreDron = drones.find(d => d.nro_serie === plan.nro_serie_drone)?.nombre || '–';

  const coords = plan.area_operacion?.coordinates?.[0];
  const center = coords
    ? [coords[0][1], coords[0][0]]
    : [-33.4489, -70.6693];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
          Aplicación de Monitoreo de Drones
        </h1>
      </header>

      {/* Título de la vista */}
      <div style={{ padding: '1rem', borderBottom: '1px solid #ddd' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '500' }}>
          Detalle de Plan de Vuelo
        </h2>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Datos de sólo lectura */}
        <div style={{ flex: 1, padding: '1rem', overflowY: 'auto' }}>
          <div style={{ marginBottom: '1rem' }}>
            <label><strong>ID:</strong></label>
            <div>{plan.id_flight_plan}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Empresa:</strong></label>
            <div>{empresaNombre}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Operador:</strong></label>
            <div>{plan.rut_operador}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Dron:</strong></label>
            <div>{nombreDron}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Trabajo:</strong></label>
            <div>{plan.trabajo}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Distancia al aeródromo:</strong></label>
            <div>{plan.distancia_aerodromo}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Altitud AGL máxima:</strong></label>
            <div>{plan.agl_max} m</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Altitud MSL máxima:</strong></label>
            <div>{plan.msl_max} m</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Tiempo de vuelo máximo:</strong></label>
            <div>{plan.tiempo_max} min</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Velocidad máxima:</strong></label>
            <div>{plan.velocidad_max} km/h</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Vuelo nocturno:</strong></label>
            <div>{plan.vuelo_nocturno ? 'Sí' : 'No'}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Fecha de inicio:</strong></label>
            <div>{new Date(plan.fecha_inicio).toLocaleString()}</div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label><strong>Fecha de fin:</strong></label>
            <div>{new Date(plan.fecha_fin).toLocaleString()}</div>
          </div>
        </div>

        {/* Mapa cuadrado e interactivo */}
        <div
          style={{
            width: '50%',
            minWidth: '300px',
            aspectRatio: '1 / 1'
          }}
        >
          <MapContainer
            center={center}
            zoom={17}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
            dragging={true}
            zoomControl={true}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; OpenStreetMap contributors"
            />
            {plan.area_operacion && (
              <GeoJSON
                data={plan.area_operacion}
                style={{
                  color: '#2563eb',
                  fillColor: '#60a5fa',
                  fillOpacity: 0.3,
                  weight: 2
                }}
              />
            )}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}
