import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';

export default function HistorialVuelo() {
  const [flights, setFlights] = useState([]);
  const [sortConfig, setSortConfig] = useState({ key: 'fecha_inicio', direction: 'desc' });
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:5000/api/flight/get_all')
      .then(resp => resp.ok ? resp.json() : Promise.reject(`HTTP ${resp.status}`))
      .then(data => setFlights(data))
      .catch(err => console.error(err));
  }, []);

  console.log("Vuelos:", flights);

  const sortedFlights = useMemo(() => {
    if (!sortConfig.key) return flights;
    return [...flights].sort((a, b) => {
      const aVal = new Date(a[sortConfig.key]);
      const bVal = new Date(b[sortConfig.key]);
      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [flights, sortConfig]);

  const requestSort = key => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
          Aplicación de Monitoreo de Drones
        </h1>
      </header>


      <div style={{ flex: 1, padding: '1rem', overflow: 'auto' }}>
        <h2 style={{ marginBottom: '1rem', fontSize: '1.25rem', fontWeight: '500' }}>
          Historial de Vuelos
        </h2>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f3f4f6' }}>
              <th style={{ padding: '8px', textAlign: 'left' }}>ID</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Empresa</th>
              <th
                style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }}
                onClick={() => requestSort('fecha_inicio')}
              >
                Fecha de inicio {sortConfig.key === 'fecha_inicio' ? (sortConfig.direction === 'asc' ? '▲' : '▼') : ''}
              </th>
              <th
                style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }}
                onClick={() => requestSort('fecha_fin')}
              >
                Fecha de fin {sortConfig.key === 'fecha_fin' ? (sortConfig.direction === 'asc' ? '▲' : '▼') : ''}
              </th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Operador</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Dron</th>
              <th style={{ padding: '8px', textAlign: 'left' }}>Detalles</th>
            </tr>
          </thead>
          <tbody>
            {sortedFlights.map(flight => (
              <tr key={flight.id_flight} style={{ borderTop: '1px solid #ddd' }}>
                <td style={{ padding: '8px' }}>{flight.id_flight}</td>
                <td style={{ padding: '8px' }}>{flight.razon_social}</td>
                <td style={{ padding: '8px' }}>{new Date(flight.fecha_inicio).toLocaleString()}</td>
                <td style={{ padding: '8px' }}>{new Date(flight.fecha_fin).toLocaleString()}</td>
                <td style={{ padding: '8px' }}>{flight.nombre_operador}</td>
                <td style={{ padding: '8px' }}>{flight.nombre_dron}</td>
                <td style={{ padding: '8px' }}>
                  <button
                    style={{
                      padding: '4px 8px',
                      backgroundColor: '#2563eb',
                      color: '#fff',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                    onClick={() => navigate(`/historial-vuelos/${flight.id_flight}`)}
                  >
                    Ver
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
