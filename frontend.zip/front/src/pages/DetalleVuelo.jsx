import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Polyline, CircleMarker, GeoJSON } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function DetalleVuelo({ companies }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vuelo, setVuelo] = useState(null);
  const [ruta, setRuta] = useState([]);
  const [plan, setPlan] = useState(null);

  const rutaDumm = [
    { lat: -33.7115279, lon: -71.0645062 },
    { lat: -33.7113569, lon: -71.0644528 },
    { lat: -33.7117399, lon: -71.0638952 },
    { lat: -33.7122847, lon: -71.0636244 }
  ];

  useEffect(() => {
    // Obtener datos del vuelo
    fetch(`http://localhost:5000/api/flight/get/${id}`)
      .then(res => res.ok ? res.json() : Promise.reject(res.status))
      .then(data => {
        setVuelo(data);
      })
      .catch(() => navigate('/historial-vuelos'));
  }, [id, navigate]);
  console.log(vuelo);

  useEffect(() => {
    // Obtener ruta del dron (telemetría)
    fetch(`http://localhost:5000/api/telemetry/get/${id}`)
      .then(res => res.ok ? res.json() : Promise.reject(res.status))
      .then(data => setRuta(data))
      .catch(err => console.error('Error obteniendo ruta:', err));
      
  }, [id]);
  console.log("RUTA", ruta);
  
  useEffect(() => {
    const fetchPlan = async () => {
      try {
        if (vuelo && vuelo.id_flight_plan) {
          const resp = await fetch(`http://localhost:5000/api/flight-plan/get/${vuelo.id_flight_plan}`);
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          setPlan(await resp.json());
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchPlan();
  }, [id, vuelo]);

  if (!vuelo) return <p>Cargando detalles…</p>;

  console.log(ruta.length);
  const center = ruta.length > 0
    ? [ruta[0].lat, ruta[0].lon]
    : [-33.4489, -80.6693];
  console.log(center);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <header style={{ backgroundColor: '#1f2937', color: '#fff', padding: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
          Aplicación de Monitoreo de Drones
        </h1>
      </header>

      <div style={{ padding: '1rem', borderBottom: '1px solid #ddd' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: '500' }}>
          Detalle de Vuelo
        </h2>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ flex: 1, padding: '1rem', overflowY: 'auto' }}>
          <div style={{ marginBottom: '1rem' }}><strong>ID:</strong> {vuelo.id_flight}</div>
          <div style={{ marginBottom: '1rem' }}><strong>Empresa:</strong> {vuelo.razon_social}</div>
          <div style={{ marginBottom: '1rem' }}><strong>Operador:</strong> {vuelo.nombre_operador}</div>
          <div style={{ marginBottom: '1rem' }}><strong>Dron:</strong> {vuelo.nombre_dron}</div>
          <div style={{ marginBottom: '1rem' }}><strong>Fecha de inicio:</strong> {new Date(vuelo.fecha_inicio).toLocaleString()}</div>
          <div style={{ marginBottom: '1rem' }}><strong>Fecha de fin:</strong> {new Date(vuelo.fecha_fin).toLocaleString()}</div>
        </div>

        <div style={{ width: '50%', minWidth: '300px', aspectRatio: '1 / 1' }}>
          <MapContainer
            key={center.join('-')}
            center={center}
            zoom={17}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; OpenStreetMap contributors"
            />
            {ruta.length > 0 && (
              <>
                <Polyline
                  positions={ruta.map(p => [p.lat, p.lon])}
                  color="red"
                  weight={4}
                />
                {rutaDumm.map((p, i) => (
                  <CircleMarker
                    key={i}
                    center={[p.lat, p.lon]}
                    radius={3}
                    pathOptions={{ color: 'black', fillOpacity: 0.7 }}
                  />
                ))}
                { plan && plan.area_operacion &&(
                  <GeoJSON
                    data={plan.area_operacion}
                    style={{
                      color: '#2563eb',
                      fillColor: '#60a5fa',
                      fillOpacity: 0.3,
                      weight: 2
                    }}
                  />
                )}
              </>
            )}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}
