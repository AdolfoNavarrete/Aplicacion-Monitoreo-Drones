from webapp import db

class Flight(db.Model):
    __tablename__ = "flights"
    id_flight = db.Column(db.Integer, primary_key=True)
    id_flight_plan = db.Column(db.Integer, db.ForeignKey("flight_plans.id_flight_plan"), nullable=False)
    fecha_inicio = db.Column(db.DateTime(timezone=True))
    fecha_fin = db.Column(db.DateTime(timezone=True))

    def to_dict(self):
        return {
            "id": self.id_flight,
            "id_flight_plan": self.id_flight_plan,
            "fecha_inicio": self.fecha_inicio,
            "fecha_fin": self.fecha_fin
        }