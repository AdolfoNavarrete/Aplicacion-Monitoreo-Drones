from webapp import db

class Drone_company(db.Model):
    __tablename__ = "drone_companies"
    id_drone_company = db.Column(db.Integer, primary_key=True)
    razon_social = db.Column(db.Text, nullable=False)
    nro_certificado = db.Column(db.Text, nullable=False)
    rut = db.Column(db.Text, nullable=False)
    actividad = db.Column(db.Text, nullable=False)
    direccion = db.Column(db.Text, nullable=False)
    nro_contacto = db.Column(db.Text, nullable=False)
    nombre_responsable = db.Column(db.Text, nullable=False)

    def to_dict(self):
        return {
            "id_drone_company": self.id_drone_company,
            "razon_social": self.razon_social,
            "nro_certificado": self.nro_certificado,
            "rut": self.rut,
            "actividad": self.actividad,
            "direccion": self.direccion,
            "nro_contacto": self.nro_contacto,
            "nombre_responsable": self.nombre_responsable
        }