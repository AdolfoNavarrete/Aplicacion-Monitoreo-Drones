from webapp import db

class Drone(db.Model):
    __tablename__ = "drones"
    nro_serie = db.Column(db.Text, primary_key=True)
    nombre = db.Column(db.Text, nullable=False)
    tipo = db.Column(db.Text, nullable=False)
    marca = db.Column(db.Text, nullable=False)
    modelo = db.Column(db.Text, nullable=False)
    fabricante = db.Column(db.Text)
    peso_fabrica = db.Column(db.Integer)
    id_drone_company = db.Column(db.Integer, db.ForeignKey("drone_companies.id_drone_company"), nullable=False)

    def to_dict(self):
        return {
            "nro_serie": self.nro_serie,
            "nombre": self.nombre,
            "tipo": self.tipo,
            "marca": self.marca,
            "modelo": self.modelo,
            "fabricante": self.fabricante,
            "peso_fabrica": self.peso_fabrica,
            "id_drone_company": self.id_drone_company
        }
