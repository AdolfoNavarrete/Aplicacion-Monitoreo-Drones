from webapp import db
from geoalchemy2 import Geometry

class Flight_plan(db.Model):
    __tablename__ = "flight_plans"
    id_flight_plan = db.Column(db.Integer, primary_key=True)
    id_drone_company = db.Column(db.Integer, db.ForeignKey("drone_companies.id_drone_company"), nullable=False)
    nro_serie_drone = db.Column(db.Integer, db.ForeignKey("drones.nro_serie"), nullable=False)
    rut_operator = db.Column(db.Text, db.ForeignKey("drone_operators.rut"), nullable=False)
    trabajo = db.Column(db.Text)
    fecha_inicio = db.Column(db.Date)
    fecha_fin = db.Column(db.Date)
    area_operacion = db.Column(Geometry(geometry_type="POLYGON", srid=4326))
    distancia_aerodromo = db.Column(db.Text)
    tipo_vuelo = db.Column(db.Text)   
    id_kmz = db.Column(db.Text)
    id_aut = db.Column(db.Text)
    id_insurance = db.Column(db.Text)
    autorizado = db.Column(db.Boolean)
    agl_max = db.Column(db.Integer)
    msl_max = db.Column(db.Integer)
    tiempo_max = db.Column(db.Integer)
    vuelo_nocturno = db.Column(db.Boolean)
    velocidad_max = db.Column(db.Integer)

    def to_dict(self):
        return {
            "id_flight_plan": self.id_flight_plan,
            "id_drone_company": self.id_drone_company,
            "nro_serie_dron": self.nro_serie_drone,
            "rut_operator": self.rut_operator,
            "trabajo": self.trabajo,
            "fecha_inicio": self.fecha_inicio.isoformat(),
            "fecha_fin": self.fecha_fin.isoformat(),
            "area_operacion": str(self.area_operacion),
            "distancia_aerodromo": self.distancia_aerodromo,
            "tipo_vuelo": self.tipo_vuelo,
            "id_kmz": self.id_kmz,
            "id_aut": self.id_aut,
            "id_seguro": self.id_insurance,
            "autorizado": self.autorizado,
            "agl_max": self.agl_max,
            "msl_max": self.msl_max,
            "tiempo_max": self.tiempo_max,
            "vuelo_nocturno": self.vuelo_nocturno,
            "velocidad_max": self.velocidad_max
        }