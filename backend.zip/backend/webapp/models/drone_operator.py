from webapp import db

class Drone_operator(db.Model):
    __tablename__ = "drone_operators"
    rut = db.Column(db.String, primary_key=True)
    id_drone_company = db.Column(db.Integer, db.ForeignKey("drone_companies.id_drone_company"), nullable=False)
    nombre = db.Column(db.Text, nullable=False)
    fecha_nacimiento = db.Column(db.Date, nullable=False)
    telefono = db.Column(db.Text)
    nro_credencial = db.Column(db.Text, nullable=False)
    fecha_emision = db.Column(db.Date, nullable=False)

    def to_dict(self):
        return {
            "rut": self.rut,
            "id_drone_company": self.id_drone_company,
            "nombre": self.nombre,
            "fecha_nacimiento": self.fecha_nacimiento.isoformat(),
            "telefono": self.telefono,
            "nro_credencial": self.nro_credencial,
            "fecha_emision": self.fecha_emision.isoformat()
        }