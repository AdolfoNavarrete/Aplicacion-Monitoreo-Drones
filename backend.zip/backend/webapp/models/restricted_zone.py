from webapp import db
from sqlalchemy.dialects.postgresql import JSONB
from geoalchemy2 import Geometry

class RestrictedZone(db.Model):
    __tablename__ = 'restricted_zones'
    id_zone = db.Column(db.Integer, primary_key=True)
    raw_feature = db.Column(JSONB, nullable=False)
    geom = db.Column(Geometry(geometry_type='POLYGON', srid=4326), nullable=False)

    def to_dict(self):
        return {
            "id_zone": self.id_zone,
            "raw_feature": self.raw_feature,
            "geom": self.geom
        }