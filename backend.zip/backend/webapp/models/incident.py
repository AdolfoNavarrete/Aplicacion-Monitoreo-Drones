from webapp import db
from geoalchemy2 import Geometry

class Incident(db.Model):
    __tablename__ = "incidents"
    id_incident = db.Column(db.Integer, primary_key=True)
    id_flight = db.Column(db.Integer, db.ForeignKey("flights.id_flight"), nullable=False)
    fecha = db.Column(db.DateTime(timezone=True))
    tipo_incidente = db.Column(db.Text)
    geom = db.Column(Geometry(geometry_type="POINT", srid=4326))

    def to_dict(self):
        return{
            "id": self.id_incident,
            "flight_id": self.id_flight,
            "fecha": self.fecha,
            "tipo_incidente": self.tipo_incidente,
            "geom": self.geom
        }
