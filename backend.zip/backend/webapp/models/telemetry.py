from webapp import db
from geoalchemy2 import Geometry
from shapely import wkb


class Telemetry(db.Model):
    __tablename__ = "telemetries"
    id_flight = db.Column(db.Integer, db.ForeignKey("flights.id_flight"), primary_key=True)
    timestmp = db.Column(db.DateTime(timezone=True), primary_key=True)
    geom = db.Column(Geometry(geometry_type="POINT", srid=4326), nullable=False)
    velocidad = db.Column(db.Float)
    bateria = db.Column(db.Float)
    direccion = db.Column(db.Float)
    altitud_agl = db.Column(db.Float)
    altitud_msl = db.Column(db.Float)

    def to_dict(self):
        try:
            raw_bytes = bytes(self.geom.data) if hasattr(self.geom, 'data') else self.geom
            punto = wkb.loads(raw_bytes)
            latitud = punto.y
            longitud = punto.x
        except:
            latitud = None
            longitud = None
        return {
            "id_flight": self.id_flight,
            "timestmp": self.timestmp,
            "lat": latitud,
            "lon": longitud,
            "velocidad": self.velocidad,
            "bateria": self.bateria,
            "direccion": self.direccion,
            "altitud_agl": self.altitud_agl,
            "altitud_msl": self.altitud_msl
        }