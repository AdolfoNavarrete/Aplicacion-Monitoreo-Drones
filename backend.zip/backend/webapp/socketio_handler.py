from datetime import datetime, timedelta
from webapp import socketio, conexiones_WebSocket
from flask_socketio import emit, join_room
from flask import request
from zoneinfo import ZoneInfo
from webapp.services import flight_plan_service, flight_service, telemetry_service, weather_service, elevation_service, sunset_service, incident_service, drone_service, drone_operator_service
from webapp.models import Telemetry
from geoalchemy2 import WKTElement

#Función que comprueba las alertas de telemetría y emite eventos a los clientes WebSocket.
def comprobar_alertas(telemetria: Telemetry):
    print("Comprobando alertas para vuelo " + str(telemetria.id_flight))
    vuelo = flight_service.obtener_vuelo_por_id(telemetria.id_flight)
    now = datetime.now(ZoneInfo("America/Santiago"))
    start = vuelo.fecha_inicio
    elapsed = now - start
    plan = flight_plan_service.obtener_plan_por_id(vuelo.id_flight_plan)
    nro_serie = plan['nro_serie_drone']
    sid = conexiones_WebSocket.get(nro_serie)
    #Rangos de alerta
    #Máxima altitud AGL y MSL
    AGL_RANGE = (plan['agl_max'] - 20, plan['agl_max'])
    MSL_RANGE = (plan['msl_max'] - 20, plan['msl_max'])
    #Tiempo máximo de vuelo
    MAX_FLIGHT_TIME_RANGE = (timedelta(minutes=plan['tiempo_max']-5), timedelta(minutes=plan['tiempo_max']))
    #Rango de batería
    BATTERY_RANGE = [20, 30]

    #Comprobación de distancia al límite del área de operación
    #Si distancia es -1, está fuera del área de operación, si es menor a 5 está cerca del límite,
    #si es False, no está autorizado a operar en esa zona.
    distancia = flight_plan_service.esta_dentro_zona(telemetria, plan['id_flight_plan'])
    print("Distancia: " + str(distancia))
    if distancia == -1:
        socketio.emit('alerta', {'message': f"Telemetría fuera de zona de operación", 'timestamp': now.isoformat()}, room=sid)
        socketio.emit('alerta', {'message': f"Telemetría fuera de zona de operación", 'timestamp': now.isoformat()}, room='frontend')
    elif distancia < 5:
        socketio.emit('alerta', {'message': f"Telemetría cerca del límite de la zona de operación: {distancia:.2f} metros", 'timestamp': now.isoformat()}, room=sid)
    elif distancia == False:
        sid = conexiones_WebSocket.get(plan['nro_serie_drone'])
        emit('alerta', {'message': 'Está operando sin autorización'}, room=sid)
    
    #Comprobación de altura AGL y MSL
    if AGL_RANGE[0] <= telemetria.altitud_agl <= AGL_RANGE[1]:
        socketio.emit('alerta', {'message': f"Altura AGL crítica: {telemetria.altitud_agl}m", 'timestamp': now.isoformat()}, room=sid)

    if MSL_RANGE[0] <= telemetria.altitud_msl <= MSL_RANGE[1]:
        socketio.emit('alerta', {'message': f"Altura MSL crítica: {telemetria.altitud_msl}m", 'timestamp': now.isoformat()}, room=sid)

    #Comprobación de batería restante
    bat = telemetria.bateria
    if BATTERY_RANGE[0] <= bat <= BATTERY_RANGE[1]:
        socketio.emit('alerta', {'message': f"Batería baja: {bat}%", 'timestamp': now.isoformat()}, room=sid)

    #Comprobación de tiempo de vuelo
    if MAX_FLIGHT_TIME_RANGE[0] <= elapsed <= MAX_FLIGHT_TIME_RANGE[1]:
        socketio.emit('alerta', {'message': f"Tiempo de vuelo cerca del límite: {elapsed}", 'timestamp': now.isoformat()}, room=sid)

    #Comprobaciones de incumplimiento de la normativa de vuelo, para aviso del fiscalizador
    #Comprobación de altitudes máximas
    if telemetria.altitud_agl > plan['agl_max']:
        socketio.emit('alerta', {'message': f"Altura AGL excedida: {telemetria.altitud_agl}m", 'timestamp': now.isoformat(), 'id_flight': vuelo.id_flight}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Altura AGL excedida',
                'geom': telemetria.geom,
            }
        incident_service.crear_incident(data)

    if telemetria.altitud_msl > plan['msl_max']:
        socketio.emit('alerta', {'message': f"Altura MSL excedida: {telemetria.altitud_msl}m", 'timestamp': now.isoformat(), 'id_flight': vuelo.id_flight}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Altura MSL excedida',
                'geom': telemetria.geom,
            }
        incident_service.crear_incident(data)

    #Comprobación de batería crítica
    if bat < BATTERY_RANGE[0]:
        socketio.emit('alerta', {'message': f"Batería crítica: {bat}%", 'timestamp': now.isoformat(), 'id_flight': vuelo.id_flight}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Batería crítica',
                'geom': telemetria.geom,
            }
        incident_service.crear_incident(data)

    #Comprobación de tiempo de vuelo
    if elapsed > MAX_FLIGHT_TIME_RANGE[1]:
        socketio.emit('alerta', {'message': f"Tiempo de vuelo excedido: {elapsed}", 'timestamp': now.isoformat(), 'id_flight': vuelo.id_flight}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Tiempo de vuelo excedido',
                'geom': telemetria.geom,
            }
        incident_service.crear_incident(data)

@socketio.on('connect')
def on_connect():
    print("Cliente conectado: " + request.sid)
    emit("welcome", {"message": "Conectado"})


@socketio.on('disconnect')
def on_disconnect(sid):
    for serial in list(conexiones_WebSocket.keys()):
        if conexiones_WebSocket[serial] == sid:
            del conexiones_WebSocket[serial]
    print("Conexiones WebSocket: " + str(conexiones_WebSocket))        
    print("Cliente desconectado: " + request.sid)

@socketio.on('connect_front')
def on_connect_front(data):
    room = data.get('room')
    join_room(room)
    print("Frontend conectado: " + request.sid + " room: " + room)

@socketio.on('ping')
def on_ping(json):
    serial = json.get('nro_serie')
    print("Recibi ping con nro_serie: " + serial)

#Maneja la conexión de los clientes WebSocket, al conectarse una app movil se recibe el nro de serie del drone,
#se crea un par (nro_serie, sid) y se agrega a un diccionario de conexiones WebSocket, y se crea una room para la conexion
#con el nombre del sid. Además, usa la longitud y latitud de la posición de dron para consultar las condiciones climáticas
#y emite alertas si las condiciones no son favorables para el vuelo. También revisa si tiene permiso para vuelo nocturno.
@socketio.on('init')
def on_init(json):
    """
    json: 
    { 
    "nro_serie": "SERIAL123"
    "lat": 0.0,
    "lon": 0.0,
    }
    """
    serial = json.get('nro_serie')
    sid = request.sid
    conexiones_WebSocket[serial] = sid
    join_room(sid)
    print("Me conecté al dron " + serial + " con sid " + sid)
    emit('conectado', {'message': 'Servidor WebSocket conectado'}, room=sid)
    #Comprobación del clima
    print("Latitud: " + str(json.get('lat')) + " Longitud: " + str(json.get('lon')))
    clima = weather_service.conseguir_clima(json.get('lat'), json.get('lon'))
    print("Niebla: " + str(clima[0]) + " Viento: " + str(clima[1]) + " Precipitación: " + str(clima[2]))
    if(clima[0] > 0.5):
        emit('alerta', {'message': 'Condiciones de niebla detectadas, vuelo no recomendado'}, room=sid)
    if(clima[1] > 8.0):
        emit('alerta', {'message': 'Viento fuerte detectado, vuelo no recomendado'}, room=sid)
    if(clima[2] > 0.0):
        emit('alerta', {'message': 'Condiciones de precipitación detectadas, vuelo no recomendado'}, room=sid)
    fecha = datetime.now(ZoneInfo("America/Santiago"))
    #Comprobación de permiso nocturno
    plan = flight_plan_service.obtener_plan_por_nro_serie(serial, fecha.date())
    puesta_sol = sunset_service.obtener_puesta_sol(json.get('lat'), json.get('lon'), tz="America/Santiago")
    if plan != -1:
        permiso_nocturno = plan.vuelo_nocturno
        if not permiso_nocturno and puesta_sol < datetime.now(ZoneInfo("America/Santiago")).time():
            emit('alerta', {'message': 'Vuelo nocturno no autorizado, no tiene permiso para operar de noche'}, room=sid)
            

#Maneja la recepción de la telemetria en la app web. Recibe un JSON con los datos de telemetría del drone,
#guarda la telemetría en la base de datos y comprueba los puntos de notificacion del protocolo.
@socketio.on('telemetria')
def on_telemetry(json):
    """
    json debe llevar:
      {
        "id_flight": "...",
        "lat":        0.0,
        "lon":        0.0,
        "altitud_agl":0.0,
        "velocidad":  0.0,
        "bateria":    0,
        "direccion":  0.0,
      }
    """
    print("Latitud: " + str(json.get('lat')) + " Longitud: " + str(json.get('lon')))
    elevacion = elevation_service.conseguir_elevacion(json['lat'], json['lon'])
    print("Elevacion: " + str(elevacion))
    altitud_msl = json['altitud_agl'] + elevacion
    data = {
        'id_flight': json.get('id_flight'),
        'lat': json.get('lat'),
        'lon': json.get('lon'),
        'altitud_agl': json.get('altitud_agl'),
        'altitud_msl': altitud_msl,
        'velocidad': json.get('velocidad'),
        'bateria': json.get('bateria'),
        'direccion': json.get('direccion'),
        'timestamp': datetime.now(ZoneInfo("America/Santiago"))
    }
    print(data)
    telemetria = telemetry_service.crear_telemetry(data)
    vuelo = flight_service.obtener_vuelo_por_id(json.get('id_flight'))
    nro_serie = flight_plan_service.obtener_serial_por_id_plan(vuelo.id_flight_plan)
    print("Nro de serie: " + nro_serie)
    mensaje = {
        'nro_serie': nro_serie,
        'telemetry': {
            'lat': json.get('lat'),
            'lon': json.get('lon'),
            'altitud_agl': json.get('altitud_agl'),
            'altitud_msl': json.get('altitud_agl') + elevacion,
            'velocidad': json.get('velocidad'),
            'bateria': json.get('bateria'),
            'direccion': json.get('direccion'),
        }
    }
    emit('telemetryUpdate', mensaje, room = 'frontend')
    comprobar_alertas(telemetria)

#Crea el vuelo en la base de datos una vez que el dron inicia el vuelo. Al iniciar el vuelo, la app movil emite
#un evento 'start_flight' con el nro de serie. Con el nro de serie, se busca el plan de vuelo asociado, y si encuentra
#un plan, se crea un vuelo en la bd y se emite un evento 'vuelo_creado' con el id del vuelo hacia la app movil. En caso de 
#no encontrar un plan de vuelo, se crea un nuevo plan de vuelo marcado como no autorizado y luego se crea el vuelo asociado.
@socketio.on('start_flight')
def on_start_flight(json):
    """
    json debe llevar:
      {
        "nro_serie": "SERIAL123",
        "lat":        0.0,
        "lon":        0.0,
      }
    """
    #Obtenemos el nro de serie del dron y la hora de inicio del vuelo
    serial = json.get('nro_serie')
    print("Recibi start_flight con nro_serie: " + serial)
    flight_start_time = datetime.now(ZoneInfo("America/Santiago"))
    print("Hora de inicio: " + str(flight_start_time))
    #Obtenemos el plan de vuelo asociado al nro de serie del dron
    plan = flight_plan_service.obtener_plan_por_nro_serie(serial, flight_start_time.date())
    print("Encontre plan 1: " + (str(plan.id_flight_plan) if hasattr(plan, 'id_flight_plan') else str(plan)))
    sid = conexiones_WebSocket.get(serial)
    print("Conexion WebSocket: " + str(conexiones_WebSocket))
    #Si el plan de vuelo existe, se crea el vuelo asociado al plan, si no existe, se crea un nuevo plan de vuelo no autorizado
    #y se crea el vuelo asociado
    if plan != -1:
        try:
            incidente = drone_operator_service.comprobar_incidentes(plan.rut_operator)
            if incidente is not None:
                emit(
                    'alerta',
                    {'message': 'El operador del vuelo registra al menos un incidente: ' + incidente.tipo_incidente},
                    room='frontend'
                )
            print("Encontre plan: " + str(plan.id_flight_plan))
            vuelo = flight_service.crear_vuelo({
                'id_flight_plan': plan.id_flight_plan,
                'fecha_inicio': flight_start_time
            })
            print("Vuelo creado con id: " + str(vuelo.id_flight))
            emit('vuelo_creado', {'vuelo_id': vuelo.id_flight}, room=sid)
            print("Mensaje emitido a la app")
            mensaje = {
                'nro_serie': serial,}
            emit('droneConnected', mensaje, room='frontend')
            print("Mensaje emitido al front")
        except Exception as e:
            print("Error al crear vuelo: " + str(e))
            emit('error', {'message': str(e)}, room=sid)
    else:
        try:
            print("No encontre plan")
            plan = flight_plan_service.crear_flight_plan({
                'nro_serie_dron': serial,
                'fecha_inicio': flight_start_time,
                'autorizado': False
            })
            print("Plan creado con id: " + str(plan.id))
            emit('vuelo_no_autorizado', {'message': 'Vuelo no autorizado en curso'}, room='frontend')
            vuelo = flight_service.crear_vuelo({
                'id_flight_plan': plan.id,
                'fecha_inicio': flight_start_time
            })
            print("Vuelo creado con id: " + str(vuelo.id_flight))
            mensaje = {
                'nro_serie': serial,}
            emit('droneConnected', mensaje, room='frontend')
            print("Mensaje emitido al front")
            emit('vuelo_creado', {'vuelo_id': vuelo.id}, room=sid)
            print("Mensaje emitido")
        except Exception as e:
            emit('error', {'message': str(e)}, room=sid)
    #Una vez creado el vuelo, se comprueba el clima y se emiten alertas al frontend para mostrar al fiscalizador en caso de 
    #condiciones adversas para el vuelo.
    clima = weather_service.conseguir_clima(json.get('lat'), json.get('lon'))
    puntoGeo = WKTElement(
                f"POINT({json['lon']} {json['lat']})",
                srid=4326
            )
    if(clima[0] > 0.4):
        emit('alerta', {'message': 'Vuelo en condiciones de niebla'}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Vuelo en condiciones de niebla',
                'geom': puntoGeo,
            }
        incident_service.crear_incident(data)
    if(clima[1] > 10.5):
        emit('alerta', {'message': 'Vuelo en condiciones de viento fuerte'}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Vuelo en condiciones de viento fuerte',
                'geom': puntoGeo,
            }
        incident_service.crear_incident(data)
    if(clima[2] > 0.0):
        emit('alerta', {'message': 'Vuelo en condiciones de precipitación'}, room='frontend')
        data = {
                'id_flight': vuelo.id_flight,
                'tipo_incidente': 'Vuelo en condiciones de precipitación',
                'geom': puntoGeo,
            }
        incident_service.crear_incident(data)
    #Comprobación de permiso nocturno
    #Si el plan de vuelo no tiene permiso nocturno y la puesta de sol ya ocurrió
    puesta_sol = sunset_service.obtener_puesta_sol(json.get('lat'), json.get('lon'), tz="America/Santiago")
    if not plan.vuelo_nocturno and puesta_sol < datetime.now(ZoneInfo("America/Santiago")).time():
            emit('alerta', {'message': 'Vuelo no tiene permiso para operar de noche'}, room=sid)


@socketio.on('stop_flight')
def on_stop_flight(json):
    """
    json: 
    { 
        "nro_serie": "SERIAL123",
        "id_flight": "...",
        "lat":        0.0,
        "lon":        0.0,
      }
    """
    serial = json.get('nro_serie')
    print("Recibi stop_flight con nro_serie: " + serial)
    flight_service.finalizar_vuelo(json.get('id_flight'))
    sid = conexiones_WebSocket.get(serial)
    print("Conexiones WebSocket: " + str(conexiones_WebSocket))
    emit('vuelo_finalizado', {'message': 'Vuelo finalizado'}, room=sid)
    mensaje = {
        'nro_serie': serial,
    }
    print("Mensaje contiene: " + str(mensaje))
    emit('droneDisconnected', mensaje, room='frontend')
    print("Mensaje emitido al front")