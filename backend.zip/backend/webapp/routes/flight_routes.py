from flask import Blueprint, request, jsonify
from webapp.services import flight_service


bp = Blueprint('flight', __name__, url_prefix='/api/flight')

@bp.route('/get_all', methods=['GET'])
def get_all_flights():
    try:
        flights = flight_service.obtener_todos_vuelos()
        return jsonify(flights)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@bp.route('/get/<id>', methods=['GET'])
def get_flight(id):
    try:
        flight = flight_service.obtener_vuelo_id(id)
        return jsonify(flight)
    except Exception as e:
        return jsonify({'error': str(e)}), 500