from flask import Flask
from webapp.routes.restricted_zone_routes import bp as restricted_zones_bp
from webapp.routes.flight_plan_routes import bp as flight_plan_bp
from webapp.routes.drone_company_routes import bp as drone_company_bp
from webapp.routes.drone_operator_routes import bp as drone_operator_bp
from webapp.routes.drone_routes import bp as drone_bp
from webapp.routes.flight_routes import bp as flight_bp
from webapp.routes.telemetry_routes import bp as telemetry_bp

def register_blueprints(app: Flask):
    app.register_blueprint(restricted_zones_bp)
    app.register_blueprint(flight_plan_bp)
    app.register_blueprint(drone_company_bp)
    app.register_blueprint(drone_operator_bp)
    app.register_blueprint(drone_bp)
    app.register_blueprint(flight_bp)
    app.register_blueprint(telemetry_bp)