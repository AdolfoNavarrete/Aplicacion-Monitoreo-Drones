from flask import Blueprint, request, jsonify
from webapp.services import restricted_zone_service
from werkzeug.exceptions import BadRequest

bp = Blueprint("rz", __name__, url_prefix="/api/restricted_zones")

@bp.route("/upload", methods=["POST"])
def upload_geojson():
    try:
        gj_text = request.get_data(as_text=True)
        if not gj_text:
            raise BadRequest("Cuerpo de la petición vacío")

        restricted_zone_service.importar_zonas(gj_text)

        return jsonify({"ok": True}), 201

    except BadRequest as e:
        return jsonify({"ok": False, "message": str(e)}), 400

    except ValueError as e:
        return jsonify({"ok": False, "message": f"GeoJSON inválido: {e}"}), 422

    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 500
    
@bp.route("/get_all", methods=["GET"])
def get_all_restricted_zones():
    try:
        restricted_zones = restricted_zone_service.obtener_todas_zonas()
        return jsonify(restricted_zones)
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)}), 500