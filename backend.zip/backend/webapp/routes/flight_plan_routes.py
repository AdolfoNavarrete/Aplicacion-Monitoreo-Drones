from flask import Blueprint, request, jsonify
from webapp.services import flight_plan_service
import xml.etree.ElementTree as ET
import zipfile
import io

bp = Blueprint('flight_plan', __name__, url_prefix='/api/flight-plan')

def coords_to_ewkt(coords, srid=4326):
    pts = ", ".join(f"{lon} {lat}" for lon, lat in coords)
    if coords[0] != coords[-1]:
        lon, lat = coords[0]
        pts += f", {lon} {lat}"
    return f"SRID={srid};POLYGON(({pts}))"


@bp.route('/create', methods=['POST'])
def crear_flight_plan():
    try:
        trabajo        = request.form['trabajo']
        fecha_inicio   = request.form['fecha_inicio']
        fecha_fin      = request.form['fecha_fin']
        dist_aerodromo = request.form['dist_aerodromo']
        tipo_vuelo     = request.form['tipo_vuelo']
        rut_operador   = request.form['rut_operador']
        nro_serie_dron = request.form['nro_serie_dron']
        agl_max        = int(request.form['agl_max'])
        msl_max        = int(request.form['msl_max'])
        tiempo_max     = int(request.form['tiempo_max'])
        vel_max        = int(request.form['vel_max'])
        vuelo_nocturno = request.form.get('vuelo_nocturno', 'false').lower() == 'true'
        id_dron_company= int(request.form['id_dron_company'])

        kmz_file       = request.files['kmzFile']
        autorizacion   = request.files['autFile']
        seguro         = request.files['insFile']

        with zipfile.ZipFile(io.BytesIO(kmz_file.read())) as z:
            kml_name = next(f for f in z.namelist() if f.lower().endswith('.kml'))
            kml_data = z.read(kml_name)

        root = ET.fromstring(kml_data)

        coords_el = root.find('.//{*}coordinates')
        if coords_el is None or not coords_el.text:
            return jsonify({'error': 'No pude encontrar <coordinates> dentro del KML'}), 400

        raw = coords_el.text.strip().split()
        coords = [[float(lon), float(lat)] for lon, lat, *_ in (pt.split(',') for pt in raw)]
        ewkt = coords_to_ewkt(coords)

        ids = flight_plan_service.guardar_archivos(kmz_file, autorizacion, seguro)

        plan_data = {
            'trabajo'         : trabajo,
            'fecha_inicio'    : fecha_inicio,  
            'fecha_fin'       : fecha_fin,
            'dist_aerodromo'  : dist_aerodromo,
            'area_operacion'  : ewkt,         
            'tipo_vuelo'      : tipo_vuelo,
            'rut_operador'    : rut_operador,
            'nro_serie_dron'  : nro_serie_dron,
            'agl_max'         : agl_max,
            'msl_max'         : msl_max,
            'tiempo_max'      : tiempo_max,
            'vel_max'         : vel_max,
            'vuelo_nocturno'  : vuelo_nocturno,
            'id_drone_company': id_dron_company,
            'autorizado'      : True,
        }

        flight_plan_service.crear_flight_plan(plan_data, ids)

        return jsonify({'message': 'Plan de vuelo creado correctamente'}), 201

    except KeyError as ke:
        return jsonify({'error': f'Falta el campo {ke.args[0]}'}), 400
    except ValueError as ve:
        return jsonify({'error': f'Formato inválido en un campo numérico: {ve}'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@bp.route('/get_all', methods=['GET'])
def get_all_flight_plans():
    try:
        flight_plans = flight_plan_service.obtener_flight_plans()
        return jsonify(flight_plans)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bp.route('/get/<id>', methods=['GET'])
def get_flight_plan(id):
    try:
        flight_plan = flight_plan_service.obtener_plan_por_id(id)
        return jsonify(flight_plan)
    except Exception as e:
        return jsonify({'error': str(e)}), 500