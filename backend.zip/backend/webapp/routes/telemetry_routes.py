from flask import Blueprint, request, jsonify
from webapp.services import telemetry_service


bp = Blueprint('telemetry', __name__, url_prefix='/api/telemetry')

@bp.route('/get/<id>', methods=['GET'])
def get_by_id_flight(id):
    try:
        telemetry = telemetry_service.obtener_telemetrias_por_vuelo(id)
        return jsonify(telemetry)
    except Exception as e:
        return jsonify({'error': str(e)}), 500