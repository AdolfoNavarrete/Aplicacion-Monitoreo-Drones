from flask import Blueprint, request, jsonify
from webapp.services import drone_operator_service

bp = Blueprint('drone_operator', __name__, url_prefix='/api/drone-operator')

@bp.route('/create', methods=['POST'])
def create_drone_operator():
    try:
        data = request.get_json()
        drone_operator_service.crear_drone_operator(data)
        return jsonify({'message': 'Operador creado correctamente'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400
    
@bp.route('/get_all', methods=['GET'])
def get_drone_operators():
    operators = drone_operator_service.obtener_operadores()
    return jsonify(operators)

@bp.route('/get/<id>', methods=['GET'])
def get_drone_operators_by_company(id):
    operators = drone_operator_service.obtener_operador_por_empresa(id)
    if operators:
        return jsonify(operators)
    return jsonify({'error': 'Operadores no encontrados'}), 404