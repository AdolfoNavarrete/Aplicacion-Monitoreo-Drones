from flask import Blueprint, request, jsonify
from webapp.services import drone_company_service

bp = Blueprint('drone_company', __name__, url_prefix='/api/drone-company')

@bp.route('/get_all', methods=['GET'])
def get_drone_companies():
    companies = drone_company_service.obtener_todas_companies()
    return jsonify(companies)

@bp.route('/create', methods=['POST'])
def create_drone_company():
    try:
        data = request.get_json()
        drone_company_service.crear_drone_company(data)
        return jsonify({'message': 'Empresa creada correctamente'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400