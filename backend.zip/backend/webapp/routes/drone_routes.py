from flask import Blueprint, request, jsonify
from webapp.services import drone_service

bp = Blueprint('drone', __name__, url_prefix='/api/drone')

@bp.route('/get_all', methods=['GET'])
def get_drones():
    drones = drone_service.obtener_todos_drones()
    return jsonify(drones)

@bp.route('/get/<id>', methods=['GET'])
def get_drones_by_company(id):
    drones = drone_service.obtener_drones_por_empresa(id)
    if drones:
        return jsonify(drones)
    return jsonify({'error': 'Drones no encontrados'}), 404

@bp.route('/create', methods=['POST'])
def create_drone():
    try:
        data = request.get_json()
        drone_service.crear_drone(data)
        return jsonify({'message': 'Drone creado correctamente'}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400