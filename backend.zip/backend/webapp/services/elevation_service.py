import requests

def conseguir_elevacion(lat: float, lon: float) -> float:
    BASE_URL = "https://api.opentopodata.org/v1/aster30m"
    try:
        resp = requests.get(
        
            BASE_URL,
            params={"locations": f"{lat},{lon}"}, 
            timeout=5
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("status") == "OK" and data.get("results"):
            elev = data["results"][0]["elevation"]
            if elev is not None:
                return elev
    except Exception:
        pass
    return 0.0
