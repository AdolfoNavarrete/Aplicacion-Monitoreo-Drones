from datetime import date
from astral import LocationInfo
from astral.sun import sun

def obtener_puesta_sol(lat: float, lon: float, tz: str = "UTC") -> str:
    city = LocationInfo(name="pos", region="", timezone=tz, latitude=lat, longitude=lon)
    s = sun(city.observer, date=date.today(), tzinfo=city.timezone)
    puesta = s["sunset"]
    return puesta.timetz()