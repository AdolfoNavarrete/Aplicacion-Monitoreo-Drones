from webapp import db
from webapp.models.incident import Incident
from zoneinfo import ZoneInfo
from datetime import datetime

def crear_incident(data):
    try:
        incidente = Incident(
            id_flight=data['id_flight'],
            fecha=datetime.now(ZoneInfo("America/Santiago")),
            tipo_incidente=data['tipo_incidente'],
            geom=data['geom']
        )
        db.session.add(incidente)
        db.session.commit()
        return incidente

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear incidente: {str(e)}")