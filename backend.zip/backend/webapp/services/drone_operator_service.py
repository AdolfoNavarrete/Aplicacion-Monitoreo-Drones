from webapp import db
from webapp.models.drone_operator import Drone_operator
from webapp.models.flight_plan import Flight_plan
from webapp.models.flight import Flight
from webapp.models.incident import Incident
from datetime import datetime

def crear_drone_operator(data):
    try:
        print("Payload recibido en crear_drone_operator:", data)
        fecha_nac = datetime.strptime(data['fecha_nacimiento'], "%Y-%m-%d").date()
        fecha_emision = datetime.strptime(data['fecha_emision'], "%Y-%m-%d").date()
        operador = Drone_operator(
            rut=data['rut'],
            id_drone_company=data['id_drone_company'],
            nombre=data['nombre'],
            fecha_nacimiento=fecha_nac,
            telefono=data['telefono'],
            nro_credencial=data['nro_credencial'],
            fecha_emision=fecha_emision
        )
        db.session.add(operador)
        db.session.commit()
        return operador
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear operador de drones: {str(e)}")

def obtener_operadores():
    try:
        operadores = db.session.query(Drone_operator).all()
        return [operador.to_dict() for operador in operadores] if operadores else []
    except Exception as e:
        raise Exception(f"Error al obtener operadores: {str(e)}")

def obtener_operador_por_empresa(id):
    try:
        operadores = Drone_operator.query.filter_by(id_drone_company=id).all()
        return [operador.to_dict() for operador in operadores] if operadores else []
    except Exception as e:
        raise Exception(f"Error al obtener operador por ID: {str(e)}")
    
def comprobar_incidentes(rut):
    try:
        planes = db.session.query(Flight_plan).filter_by(rut_operator=rut).all()
        for plan in planes:
            vuelos = db.session.query(Flight).filter_by(id_flight_plan=plan.id_flight_plan).all()
            for vuelo in vuelos:
                incidentes = db.session.query(Incident).filter_by(id_flight=vuelo.id_flight).all()
                if len(incidentes) > 0:
                    return incidentes[0]
        return None
    except Exception as e:
        raise Exception(f"Error al comprobar incidentes: {str(e)}")