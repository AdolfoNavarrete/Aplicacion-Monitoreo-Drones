from webapp import db
from webapp.models.drone_company import Drone_company

def crear_drone_company(data):
    try:
        drone_company = Drone_company(
            razon_social=data['razon_social'],
            nro_certificado=data['nro_certificado'],
            rut=data['rut'],
            actividad=data['actividad'],
            direccion=data['direccion'],
            nro_contacto=data['nro_contacto'],
            nombre_responsable=data['nombre_responsable']
        )

        db.session.add(drone_company)
        db.session.commit()
        return drone_company

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear plan de vuelo: {str(e)}")
    
def obtener_todas_companies():
    try:
        companies = Drone_company.query.all()
        return [company.to_dict() for company in companies]
    except Exception as e:
        raise Exception(f"Error al obtener empresas: {str(e)}")