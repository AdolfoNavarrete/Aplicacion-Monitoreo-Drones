from webapp import db, mongo
from webapp.models.flight_plan import Flight_plan
from datetime import datetime
from zoneinfo import ZoneInfo
from sqlalchemy import func
from geoalchemy2 import Geometry
import json

def crear_flight_plan(data, ids):
    try:
        plan = Flight_plan(
            id_drone_company=data['id_drone_company'],
            trabajo=data['trabajo'],
            fecha_inicio=datetime.strptime(data['fecha_inicio'], "%Y-%m-%d").date(),
            fecha_fin=datetime.strptime(data['fecha_fin'], "%Y-%m-%d").date(),
            area_operacion=data['area_operacion'],
            distancia_aerodromo=data['dist_aerodromo'],
            tipo_vuelo=data['tipo_vuelo'],
            id_kmz=str(ids[0]),
            id_aut=str(ids[1]),
            id_insurance=str(ids[2]),
            nro_serie_drone=data['nro_serie_dron'],
            rut_operator=data['rut_operador'],
            autorizado=data['autorizado'],
            agl_max=data['agl_max'],
            msl_max=data['msl_max'],
            tiempo_max=data['tiempo_max'], 
            vuelo_nocturno=data['vuelo_nocturno'],
            velocidad_max=data['vel_max']
        )

        db.session.add(plan)
        db.session.commit()
        return plan

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear plan de vuelo: {str(e)}")
    
def guardar_archivos(kmz_file, autorizacion_file, seguro_file):
    kmz_id = mongo.db.flight_zone.insert_one({
        "nombre": kmz_file.filename,
        "contenido": kmz_file.read(),
        "fecha_subida": datetime.now(ZoneInfo("America/Santiago")),
    }).inserted_id

    aut_id = mongo.db.authorizations.insert_one({
        "nombre": autorizacion_file.filename,
        "contenido": autorizacion_file.read(),
        "fecha_subida": datetime.now(ZoneInfo("America/Santiago")),
    }).inserted_id

    insurance_id = mongo.db.insurances.insert_one({
        "nombre": seguro_file.filename,
        "contenido": seguro_file.read(),
        "fecha_subida": datetime.now(ZoneInfo("America/Santiago")),
    }).inserted_id

    ids = [kmz_id, aut_id, insurance_id]

    return ids

def obtener_plan_por_id(id_plan):
    try:
        row = (
            db.session
              .query(
                Flight_plan.id_flight_plan,
                Flight_plan.id_drone_company,
                Flight_plan.nro_serie_drone,
                Flight_plan.rut_operator,
                Flight_plan.trabajo,
                Flight_plan.fecha_inicio,
                Flight_plan.fecha_fin,
                func.ST_AsGeoJSON(Flight_plan.area_operacion).label("area_operacion"),
                Flight_plan.distancia_aerodromo,
                Flight_plan.tipo_vuelo,
                Flight_plan.id_kmz,
                Flight_plan.id_aut,
                Flight_plan.id_insurance,
                Flight_plan.autorizado,
                Flight_plan.agl_max,
                Flight_plan.msl_max,
                Flight_plan.tiempo_max,
                Flight_plan.vuelo_nocturno,
                Flight_plan.velocidad_max
              )
              .filter_by(id_flight_plan=id_plan)
              .first()
        )
        if not row:
            return None

        return {
            "id_flight_plan": row.id_flight_plan,
            "id_drone_company": row.id_drone_company,
            "nro_serie_drone": row.nro_serie_drone,
            "rut_operador": row.rut_operator,
            "trabajo": row.trabajo,
            "fecha_inicio": row.fecha_inicio.isoformat(),
            "fecha_fin": row.fecha_fin.isoformat(),
            "area_operacion": json.loads(row.area_operacion),
            "distancia_aerodromo": row.distancia_aerodromo,
            "tipo_vuelo": row.tipo_vuelo,
            "id_kmz": row.id_kmz,
            "id_aut": row.id_aut,
            "id_seguro": row.id_insurance,
            "autorizado": row.autorizado,
            "agl_max": row.agl_max,
            "msl_max": row.msl_max,
            "tiempo_max": row.tiempo_max,
            "vuelo_nocturno": row.vuelo_nocturno,
            "velocidad_max": row.velocidad_max
        }
    except Exception as e:
        raise Exception(f"Error al obtener plan de vuelo por ID: {str(e)}")

def obtener_plan_por_nro_serie(nro_serie, time):
    try:
        plans = db.session.query(Flight_plan).filter_by(nro_serie_drone=nro_serie).all()
        if not plans:
            raise Exception("No se encontraron planes de vuelo para este número de serie")
        else:
            for plan in plans:
                if plan.fecha_inicio <= time <= plan.fecha_fin:
                    return plan
        return -1
    except Exception as e:
        raise Exception(f"Error al obtener planes de vuelo por número de serie: {str(e)}")

def esta_activo(planes, time):
    try:
        for plan in planes:
            if plan.fecha_inicio <= time <= plan.fecha_fin:
                return plan.id
        return False
    except Exception as e:
        raise Exception(f"Error al verificar si el plan de vuelo está activo: {str(e)}")
    except Exception as e:
        raise Exception(f"Error al verificar si el plan de vuelo está activo: {str(e)}")
    
def esta_dentro_zona(telemetria, id_plan):
    poligono = db.session.query(Flight_plan.area_operacion).filter_by(id_flight_plan=id_plan).scalar()
    if not poligono:
        return False
    
    punto = telemetria.geom

    dentro = db.session.query(
        func.ST_Within(punto, poligono)
    ).scalar()
    if dentro:
        distancia_grados = db.session.query(
            func.ST_Distance(punto, func.ST_Boundary(poligono))
        ).scalar()
        distancia = distancia_grados * 111320
        distancia = round(distancia, 2)
        return distancia
    else:
        return -1
    
def obtener_flight_plans():
    try:
        flight_plans = db.session.query(Flight_plan).all()
        return [plan.to_dict() for plan in flight_plans]
    except Exception as e:
        raise Exception(f"Error al obtener planes de vuelo: {str(e)}")
    
def obtener_serial_por_id_plan(id):
    try:
        nro_serie = db.session.query(Flight_plan.nro_serie_drone).filter_by(id_flight_plan=id).scalar()
        return nro_serie
    except Exception as e:
        raise Exception(f"Error al obtener serial por ID de plan de vuelo: {str(e)}")