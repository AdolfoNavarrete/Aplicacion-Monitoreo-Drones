from webapp import db
from webapp.models.flight import Flight
from webapp.models.flight_plan import Flight_plan
from webapp.models.drone_operator import Drone_operator
from webapp.models.drone import Drone
from webapp.models.drone_company import Drone_company
from datetime import datetime
from zoneinfo import ZoneInfo

def crear_vuelo(data):
    try:
        vuelo = Flight(
            id_flight_plan=data['id_flight_plan'],
            fecha_inicio=data['fecha_inicio'],
        )

        db.session.add(vuelo)
        db.session.commit()
        return vuelo

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear vuelo: {str(e)}")
    
def finalizar_vuelo(id_vuelo):
    try:
        vuelo = db.session.query(Flight).filter_by(id_flight=id_vuelo).first()
        if not vuelo:
            raise Exception("Vuelo no encontrado")

        vuelo.fecha_fin = datetime.now(ZoneInfo("America/Santiago"))
        db.session.commit()
        return vuelo

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al finalizar vuelo: {str(e)}")
    
def obtener_vuelo_por_id(id_vuelo):
    try:
        vuelo = db.session.query(Flight).filter_by(id_flight=id_vuelo).first()
        if not vuelo:
            raise Exception("Vuelo no encontrado")
        return vuelo

    except Exception as e:
        raise Exception(f"Error al obtener vuelo por ID: {str(e)}")
    
def obtener_todos_vuelos():
    try:
        vuelos = db.session.query(Flight).all()
        flights = []
        for vuelo in vuelos:
            plan = db.session.query(Flight_plan).filter_by(id_flight_plan=vuelo.id_flight_plan).first()
            empresa = db.session.query(Drone_company).filter_by(id_drone_company=plan.id_drone_company).first()
            operador = db.session.query(Drone_operator).filter_by(rut=plan.rut_operator).first()
            dron = db.session.query(Drone).filter_by(nro_serie=plan.nro_serie_drone).first()
            if vuelo.fecha_fin is not None:
                fecha_fin = vuelo.fecha_fin.strftime("%Y-%m-%d %H:%M:%S %Z")
            else:
                fecha_fin = "-"
            if vuelo.fecha_inicio is not None:
                fecha_inicio = vuelo.fecha_inicio.strftime("%Y-%m-%d %H:%M:%S %Z")
            else:
                fecha_inicio = "-"
            flight = {
                "id_flight": vuelo.id_flight,
                "fecha_inicio": fecha_inicio,
                "fecha_fin": fecha_fin,
                "razon_social": empresa.razon_social,
                "nombre_dron": dron.nombre,
                "nombre_operador": operador.nombre,
            }
            flights.append(flight)
        return flights

    except Exception as e:
        raise Exception(f"Error al obtener todos los vuelos: {str(e)}")
    
def obtener_vuelo_id(id_vuelo):
    try:
        vuelo = db.session.query(Flight).filter_by(id_flight=id_vuelo).first()
        plan = db.session.query(Flight_plan).filter_by(id_flight_plan=vuelo.id_flight_plan).first()
        empresa = db.session.query(Drone_company).filter_by(id_drone_company=plan.id_drone_company).first()
        operador = db.session.query(Drone_operator).filter_by(rut=plan.rut_operator).first()
        dron = db.session.query(Drone).filter_by(nro_serie=plan.nro_serie_drone).first()
        if vuelo.fecha_fin is not None:
            fecha_fin = vuelo.fecha_fin.strftime("%Y-%m-%d %H:%M:%S %Z")
        else:
            fecha_fin = "-"
        if vuelo.fecha_inicio is not None:
            fecha_inicio = vuelo.fecha_inicio.strftime("%Y-%m-%d %H:%M:%S %Z")
        else:
            fecha_inicio = "-"
        vuelo = {
            "id_flight": vuelo.id_flight,
            "id_flight_plan": vuelo.id_flight_plan,
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "razon_social": empresa.razon_social,
            "nombre_dron": dron.nombre,
            "nombre_operador": operador.nombre
        }
        if not vuelo:
            raise Exception("Vuelo no encontrado")
        return vuelo

    except Exception as e:
        raise Exception(f"Error al obtener vuelo por ID: {str(e)}")