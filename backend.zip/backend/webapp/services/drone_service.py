from webapp import db
from webapp.models.drone import Drone

def crear_drone(data):
    try:
        print("Payload recibido en crear_drone:", data)
        drone = Drone(
            nombre=data['nombre'],
            tipo=data['tipo'],
            marca=data['marca'],
            modelo=data['modelo'],
            nro_serie=data['nro_serie'],
            fabricante=data['fabricante'],
            peso_fabrica=data['peso_fabrica'],
            id_drone_company=data['id_drone_company']
        )

        db.session.add(drone)
        db.session.commit()
        return drone

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear dron: {str(e)}")
    
def obtener_drone_por_serial(nro_serie):
    try:
        drone = db.session.query(Drone).filter_by(nro_serie=nro_serie).first()
        if not drone:
            raise Exception("Drone no encontrado")
        return drone
    except Exception as e:
        raise Exception(f"Error al obtener drone por serial: {str(e)}")
    
def obtener_drone_company_por_serial(nro_serie):
    try:
        drone_company = db.session.query(Drone).filter_by(nro_serie=nro_serie).first()
        if not drone_company:
            raise Exception("ID de empresa no encontrada")
        return drone_company
    except Exception as e:
        raise Exception(f"Error al obtener id de empresa por serial: {str(e)}")
    
def obtener_drones_por_empresa(id_drone_company):
    try:
        drones = db.session.query(Drone).filter_by(id_drone_company=id_drone_company).all()
        return [drone.to_dict() for drone in drones] if drones else []
    except Exception as e:
        raise Exception(f"Error al obtener drones por ID de empresa: {str(e)}")
    
def obtener_todos_drones():
    try:
        drones = db.session.query(Drone).all()
        return [drone.to_dict() for drone in drones] if drones else []
    except Exception as e:
        raise Exception(f"Error al obtener todos los drones: {str(e)}")