from webapp import db
from webapp.models.telemetry import Telemetry
from geoalchemy2 import WKTElement, Geography
from sqlalchemy import func

def crear_telemetry(data: dict):
    try:
        t = Telemetry(
        id_flight = data['id_flight'],
        timestmp = data['timestamp'],
        geom = WKTElement(
                f"POINT({data['lon']} {data['lat']})",
                srid=4326
            ),
        velocidad = data['velocidad'],
        bateria = data['bateria'],
        direccion = data['direccion'],
        altitud_agl = data['altitud_agl'],
        altitud_msl = data['altitud_msl']
    )
        db.session.add(t)
        db.session.commit()
        return t

    except Exception as e:
        db.session.rollback()
        raise Exception(f"Error al crear telemetría: {str(e)}")
    
def obtener_telemetrias_por_vuelo(id_vuelo):
    try:
        telemetrias = (
            db.session.query(Telemetry)
            .filter_by(id_flight=id_vuelo)
            .order_by(Telemetry.timestmp.asc())
            .all()
        )
        return [telemetria.to_dict() for telemetria in telemetrias]
    except Exception as e:
        raise Exception(f"Error al obtener telemetrias por vuelo: {str(e)}")