import json
from shapely.geometry import shape
from geoalchemy2.elements import WKTElement
from sqlalchemy import func
from webapp import db
from webapp.models.restricted_zone import RestrictedZone

def importar_zonas(geojson_str):
    coll = json.loads(geojson_str)
    for feat in coll.get("features", []):
        geom = shape(feat["geometry"])
        poly_wkt = geom.wkt
        wkt_elem = WKTElement(poly_wkt, srid=4326)

        existe = (
            db.session
              .query(RestrictedZone.id_zone)
              .filter(func.ST_Equals(RestrictedZone.geom, wkt_elem))
              .first()
        )
        if existe:
            continue

        zone = RestrictedZone(
            geom=wkt_elem,
            raw_feature=feat
        )
        db.session.add(zone)
    db.session.commit()

def obtener_todas_zonas():
    try:
        rows = (
            db.session
              .query(
                RestrictedZone.id_zone,
                RestrictedZone.raw_feature,
                func.ST_AsGeoJSON(RestrictedZone.geom).label("geom_json")
              )
              .all()
        )

        features = []
        for id_zone, raw_feature, geom_json in rows:
            feature = {
                "type": "Feature",
                "geometry": json.loads(geom_json),
                "properties": raw_feature.get("properties", {})
            }
            feature["properties"]["id_zone"] = id_zone
            features.append(feature)

        return {
            "type": "FeatureCollection",
            "features": features
        }
    except Exception as e:
        raise Exception(f"Error al obtener zonas: {str(e)}")