import requests

def conseguir_clima(lat: float, lon: float) -> dict:
    BASE_URL = "https://api.met.no/weatherapi/locationforecast/2.0/compact"
    headers = {
        "User-Agent": "proyecto-drones adolfo.navarrete@usach.cl"
    }
    params = {
        "lat": lat,
        "lon": lon
    }
    try:
        resp = requests.get(
            BASE_URL,
            headers=headers,
            params=params,
            timeout=5
        )
        resp.raise_for_status()
        data = resp.json()
        tl = data["properties"]["timeseries"][0]["data"]
        niebla = tl.get("instant", {}).get("details", {}).get("fog_area_fraction", 0.0)
        viento = tl.get("instant", {}).get("details", {}).get("wind_speed", 0.0)
        precipitacion = tl.get("next_1_hours", {}).get("details", {}).get("precipitation_amount", 0.0)
        clima = [niebla, viento, precipitacion]
        return clima
    except Exception:
        return None