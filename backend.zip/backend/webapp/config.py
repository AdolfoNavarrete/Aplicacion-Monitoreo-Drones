import os

class Config:

    MONGO_URI = os.environ.get(
        "MONGO_URI", "mongodb://localhost:27017/drones_db"
    )

    # URI Postgres
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "postgresql+psycopg2://postgres:pos123@localhost:5432/drones_db"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    JSONIFY_PRETTYPRINT_REGULAR = False