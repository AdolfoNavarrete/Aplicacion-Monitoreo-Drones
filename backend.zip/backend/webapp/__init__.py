from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_pymongo import PyMongo
from flask_cors import CORS
from flask_socketio import SocketIO

db = SQLAlchemy()
mongo = PyMongo()
socketio = SocketIO(cors_allowed_origins="*", path='/socket.io') 

# Diccionario para almacenar las conexiones WebSocket activas
conexiones_WebSocket: dict[str, str] = {}  # {nro_serie: sid}

def create_app():
    flask_app = Flask(__name__)
    flask_app.config.from_object('webapp.config.Config')

    db.init_app(flask_app)
    mongo.init_app(flask_app)
    CORS(flask_app)
    socketio.init_app(flask_app)

    from webapp.routes import register_blueprints
    register_blueprints(flask_app)

    import webapp.socketio_handler

    return flask_app